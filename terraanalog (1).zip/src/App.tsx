import { useCallback, useEffect, useMemo, useState } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import {
  AnalogDimensionKey,
  buildCsvExport,
  computeThermalAxis,
  DEFAULT_DIMENSION_WEIGHTS,
  DimensionWeights,
  EarthAnalogSite,
  fetchNasaPowerPoint,
  INITIAL_EARTH_ANALOG_SITES,
  PLANETARY_TARGETS,
  rankAnalogsForTarget,
} from './data/planetaryAnalogs';
import { DiscoveryLabView } from './components/DiscoveryLabView';
import { GlobalAnalogMap } from './components/GlobalAnalogMap';
import { MoonAndMarsView } from './components/MoonAndMarsView';
import { ScientificBriefView } from './components/ScientificBriefView';

type ActiveTab = 'lab' | 'map' | 'worlds' | 'brief';

const MAPS_API_KEY: string =
  import.meta.env.VITE_GOOGLE_MAPS_API_KEY ||
  (globalThis as unknown as { GOOGLE_MAPS_API_KEY?: string })
    .GOOGLE_MAPS_API_KEY ||
  '';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('lab');
  const [earthSites, setEarthSites] = useState<EarthAnalogSite[]>(
    INITIAL_EARTH_ANALOG_SITES
  );
  const [targetId, setTargetId] = useState<string>(PLANETARY_TARGETS[0].id);
  const [bodyFilter, setBodyFilter] = useState<'All' | 'Moon' | 'Mars'>('All');
  const [weights, setWeights] = useState<DimensionWeights>(
    DEFAULT_DIMENSION_WEIGHTS
  );
  const [selectedSiteId, setSelectedSiteId] = useState<string>(
    INITIAL_EARTH_ANALOG_SITES[0].id
  );
  const [quotaExceeded, setQuotaExceeded] = useState(false);

  const [mapsAuthFailed, setMapsAuthFailed] = useState(false);

  useEffect(() => {
    const onQuotaExceeded = () => setQuotaExceeded(true);
    const prevAuthFailure = (
      window as unknown as { gm_authFailure?: () => void }
    ).gm_authFailure;
    (window as unknown as { gm_authFailure?: () => void }).gm_authFailure =
      () => {
        setMapsAuthFailed(true);
        prevAuthFailure?.();
      };

    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => {
      window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
      (window as unknown as { gm_authFailure?: () => void }).gm_authFailure =
        prevAuthFailure;
    };
  }, []);

  // Load live NASA POWER climatology for each Earth analog site
  useEffect(() => {
    let cancelled = false;

    const loadNasaPower = async () => {
      await Promise.all(
        INITIAL_EARTH_ANALOG_SITES.map(async (site) => {
          try {
            const obs = await fetchNasaPowerPoint(site.lat, site.lon, true);
            if (cancelled) return;
            setEarthSites((prev) =>
              prev.map((item) => {
                if (item.id !== site.id) return item;
                const src =
                  obs.solar != null
                    ? 'NASA POWER (temperature, rainfall, pressure) + solar flux'
                    : 'NASA POWER (temperature, rainfall, pressure)';
                return {
                  ...item,
                  temp: obs.temp,
                  rng: obs.rng,
                  rain: obs.rain,
                  press: obs.press,
                  solar: obs.solar,
                  src,
                  nasaLoaded: true,
                  vector: {
                    ...item.vector,
                    thermal: computeThermalAxis(obs.temp, obs.rng),
                  },
                };
              })
            );
          } catch {
            // Keep literature estimate on network/API fallback
          }
        })
      );
    };

    loadNasaPower();
    return () => {
      cancelled = true;
    };
  }, []);

  const activeTarget = useMemo(
    () =>
      PLANETARY_TARGETS.find((t) => t.id === targetId) ?? PLANETARY_TARGETS[0],
    [targetId]
  );

  const rankedResults = useMemo(
    () => rankAnalogsForTarget(earthSites, targetId, weights, bodyFilter),
    [earthSites, targetId, weights, bodyFilter]
  );

  // Default to top-ranked site when filter excludes current selection
  useEffect(() => {
    if (
      rankedResults.length > 0 &&
      !rankedResults.some((r) => r.site.id === selectedSiteId)
    ) {
      setSelectedSiteId(rankedResults[0].site.id);
    }
  }, [rankedResults, selectedSiteId]);

  const handleWeightChange = useCallback(
    (key: AnalogDimensionKey, value: number) => {
      setWeights((prev) => ({ ...prev, [key]: value }));
    },
    []
  );

  const handleResetWeights = useCallback(() => {
    setWeights(DEFAULT_DIMENSION_WEIGHTS);
  }, []);

  const handleTargetChange = useCallback(
    (nextTargetId: string) => {
      setTargetId(nextTargetId);
      const nextRanked = rankAnalogsForTarget(
        earthSites,
        nextTargetId,
        weights,
        bodyFilter
      );
      if (nextRanked.length > 0) {
        setSelectedSiteId(nextRanked[0].site.id);
      }
    },
    [earthSites, weights, bodyFilter]
  );

  const handleExportCsv = useCallback(() => {
    const csv = buildCsvExport(rankedResults);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `analog_ranking_${activeTarget.id}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [rankedResults, activeTarget.id]);

  const nasaLoadedCount = useMemo(
    () => earthSites.filter((s) => s.nasaLoaded).length,
    [earthSites]
  );

  const hasApiKey = Boolean(MAPS_API_KEY) && !mapsAuthFailed;

  const appShell = (
    <div className="min-h-screen flex flex-col bg-[#07090E] text-slate-100">
      {quotaExceeded && hasApiKey && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2 text-xs text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached —{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              view quota details
            </a>
            .
          </span>
        </div>
      )}

      {/* Top Bar */}
      <header className="h-[60px] flex items-center justify-between gap-8 px-6 border-b border-slate-800 bg-[#07090E] shrink-0">
        <button
          type="button"
          onClick={() => setActiveTab('lab')}
          className="text-lg font-display font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0 cursor-pointer"
        >
          Terra<span className="text-cyan-400">Analog</span>
        </button>

        <nav
          aria-label="Primary workspace navigation"
          className="flex items-center gap-6 overflow-x-auto"
        >
          {(
            [
              ['lab', 'Discovery Lab'],
              ['map', 'Global Map'],
              ['worlds', 'Moon & Mars'],
              ['brief', 'Scientific Brief'],
            ] as const
          ).map(([tabId, label]) => {
            const isActive = activeTab === tabId;
            return (
              <button
                key={tabId}
                type="button"
                onClick={() => setActiveTab(tabId)}
                className={`py-1.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'text-cyan-400 border-cyan-400'
                    : 'text-slate-400 border-transparent hover:text-slate-100 hover:border-slate-700'
                }`}
              >
                {label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={handleExportCsv}
            className="px-4 py-2 text-xs font-medium text-slate-950 bg-cyan-400 rounded hover:bg-cyan-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Export CSV
          </button>
        </div>
      </header>

      {/* Active View */}
      <div className="flex-1 min-h-0">
        {activeTab === 'lab' && (
          <DiscoveryLabView
            targetId={targetId}
            onChangeTarget={handleTargetChange}
            bodyFilter={bodyFilter}
            onChangeBodyFilter={setBodyFilter}
            weights={weights}
            onChangeWeight={handleWeightChange}
            onResetWeights={handleResetWeights}
            results={rankedResults}
            selectedSiteId={selectedSiteId}
            onSelectSite={setSelectedSiteId}
            onOpenMap={(siteId) => {
              setSelectedSiteId(siteId);
              setActiveTab('map');
            }}
            hasApiKey={hasApiKey}
          />
        )}

        {activeTab === 'map' && (
          <GlobalAnalogMap
            results={rankedResults}
            allEarthSites={earthSites}
            activeTarget={activeTarget}
            selectedSiteId={selectedSiteId}
            onSelectSite={setSelectedSiteId}
            hasApiKey={hasApiKey}
          />
        )}

        {activeTab === 'worlds' && (
          <MoonAndMarsView
            onSelectTargetAndExplore={(nextTargetId) => {
              handleTargetChange(nextTargetId);
              setActiveTab('lab');
            }}
          />
        )}

        {activeTab === 'brief' && (
          <ScientificBriefView
            nasaLoadedCount={nasaLoadedCount}
            totalEarthSites={earthSites.length}
          />
        )}
      </div>
    </div>
  );

  if (!MAPS_API_KEY) {
    return appShell;
  }

  return (
    <APIProvider
      apiKey={MAPS_API_KEY}
      language="en"
      region="US"
      libraries={['marker', 'geocoding']}
    >
      {appShell}
    </APIProvider>
  );
}
