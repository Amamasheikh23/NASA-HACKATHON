export type AnalogDimensionKey =
  | 'geology'
  | 'terrain'
  | 'thermal'
  | 'waterIce'
  | 'subsurface'
  | 'aeolian'
  | 'biosignature'
  | 'mobility';

export type DimensionVector = Record<AnalogDimensionKey, number>;
export type DimensionWeights = Record<AnalogDimensionKey, number>;

export interface DimensionMetadata {
  key: AnalogDimensionKey;
  label: string;
  shortLabel: string;
  provenance: 'computed' | 'estimate';
  provenanceLabel: string;
}

export const ANALOG_DIMENSIONS: DimensionMetadata[] = [
  {
    key: 'geology',
    label: 'Geology & Mineralogy',
    shortLabel: 'Geology',
    provenance: 'estimate',
    provenanceLabel: 'Literature-based estimate',
  },
  {
    key: 'terrain',
    label: 'Terrain & Slope Roughness',
    shortLabel: 'Terrain',
    provenance: 'estimate',
    provenanceLabel: 'Slope formula (estimated slope, not NASA raster)',
  },
  {
    key: 'thermal',
    label: 'Thermal & Illumination Extremes',
    shortLabel: 'Thermal',
    provenance: 'computed',
    provenanceLabel: 'Computed (NASA POWER temp & annual range)',
  },
  {
    key: 'waterIce',
    label: 'Water, Permafrost & ISRU',
    shortLabel: 'Water/ISRU',
    provenance: 'estimate',
    provenanceLabel: 'Literature-based estimate',
  },
  {
    key: 'subsurface',
    label: 'Subsurface & Lava Tubes',
    shortLabel: 'Subsurface',
    provenance: 'estimate',
    provenanceLabel: 'Literature-based estimate',
  },
  {
    key: 'aeolian',
    label: 'Aeolian & Regolith Dust',
    shortLabel: 'Dust/Wind',
    provenance: 'estimate',
    provenanceLabel: 'Literature-based estimate',
  },
  {
    key: 'biosignature',
    label: 'Extremophiles & Biosignatures',
    shortLabel: 'Biosignature',
    provenance: 'estimate',
    provenanceLabel: 'Literature-based estimate',
  },
  {
    key: 'mobility',
    label: 'Rover Mobility & EVA Ops',
    shortLabel: 'Mobility',
    provenance: 'estimate',
    provenanceLabel: 'Literature-based estimate',
  },
];

export const DEFAULT_DIMENSION_WEIGHTS: DimensionWeights = {
  geology: 1.0,
  terrain: 0.9,
  thermal: 0.85,
  waterIce: 0.85,
  subsurface: 0.75,
  aeolian: 0.65,
  biosignature: 0.6,
  mobility: 0.8,
};

export interface PlanetaryTargetSite {
  id: string;
  name: string;
  focus: 'Moon' | 'Mars';
  region: string;
  lat: number;
  lon: number;
  elev: number;
  temp: number;
  rng: number;
  rain: number;
  press: number;
  slope: number;
  gravity: number;
  use: string;
  vector: DimensionVector; // normalized 0..1
}

export interface EarthAnalogSite {
  id: string;
  name: string;
  focus: 'Moon' | 'Mars' | 'Moon and Mars';
  region: string;
  lat: number;
  lon: number;
  elev: number;
  temp: number;
  rng: number;
  rain: number;
  press: number;
  slope: number;
  solar: number | null;
  use: string;
  limits: string;
  src: string;
  nasaLoaded: boolean;
  vector: DimensionVector; // normalized 0..1
}

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export function computeThermalAxis(temp: number, rng: number): number {
  return (
    Math.round(
      100 * (0.6 * clamp01((25 - temp) / 115) + 0.4 * clamp01(rng / 100))
    ) / 100
  );
}

export function computeTerrainAxis(slope: number): number {
  return Math.round(100 * clamp01(slope / 20)) / 100;
}

export const PLANETARY_TARGETS: PlanetaryTargetSite[] = [
  {
    id: 'moon_shackleton',
    name: 'Shackleton Rim and Connecting Ridge',
    focus: 'Moon',
    region: 'Lunar south pole',
    lat: -89.9,
    lon: 0.0,
    elev: 0,
    temp: -85,
    rng: 70,
    rain: 0,
    press: 0,
    slope: 10,
    gravity: 1.62,
    use: 'Permanent lunar base and polar ice ISRU: near-continuous sunlight on ridge crests beside permanently shadowed craters that trap water ice.',
    vector: {
      geology: 0.7,
      terrain: computeTerrainAxis(10),
      thermal: computeThermalAxis(-85, 70),
      waterIce: 0.9,
      subsurface: 0.2,
      aeolian: 0.95,
      biosignature: 0.05,
      mobility: 0.55,
    },
  },
  {
    id: 'moon_marius',
    name: 'Marius Hills Pit and Lava Tube',
    focus: 'Moon',
    region: 'Oceanus Procellarum',
    lat: 14.1,
    lon: -56.7,
    elev: 0,
    temp: -20,
    rng: 290,
    rain: 0,
    press: 0,
    slope: 5,
    gravity: 1.62,
    use: 'Candidate base site: basaltic plains with a lava-tube skylight that could shelter crews from radiation and temperature swings.',
    vector: {
      geology: 0.95,
      terrain: computeTerrainAxis(5),
      thermal: computeThermalAxis(-20, 290),
      waterIce: 0.05,
      subsurface: 0.95,
      aeolian: 0.95,
      biosignature: 0.05,
      mobility: 0.7,
    },
  },
  {
    id: 'moon_tranquillitatis',
    name: 'Mare Tranquillitatis Pit and Basalt Plain',
    focus: 'Moon',
    region: 'Mare Tranquillitatis',
    lat: 8.3,
    lon: 33.2,
    elev: -1900,
    temp: -20,
    rng: 280,
    rain: 0,
    press: 0,
    slope: 3,
    gravity: 1.62,
    use: 'Contains a lunar skylight pit that may provide access to a subsurface cavity or potential lava-tube structure. The full extent and continuity of the underground structure remain uncertain.',
    vector: {
      geology: 0.9,
      terrain: computeTerrainAxis(3),
      thermal: computeThermalAxis(-20, 280),
      waterIce: 0.05,
      subsurface: 0.95,
      aeolian: 0.9,
      biosignature: 0.05,
      mobility: 0.85,
    },
  },
  {
    id: 'moon_aristarchus',
    name: 'Aristarchus Plateau and Vallis Schröteri',
    focus: 'Moon',
    region: 'Oceanus Procellarum NW',
    lat: 23.7,
    lon: -47.4,
    elev: 2000,
    temp: -30,
    rng: 270,
    rain: 0,
    press: 0,
    slope: 8,
    gravity: 1.62,
    use: 'Lunar pyroclastic glass blanket and giant sinuous rille: prime target for volatile/oxygen ISRU and volcanic stratigraphy.',
    vector: {
      geology: 0.95,
      terrain: computeTerrainAxis(8),
      thermal: computeThermalAxis(-30, 270),
      waterIce: 0.25,
      subsurface: 0.6,
      aeolian: 0.85,
      biosignature: 0.05,
      mobility: 0.65,
    },
  },
  {
    id: 'moon_tycho',
    name: 'Tycho Crater Rim and Impact Melt Sheet',
    focus: 'Moon',
    region: 'Southern lunar highlands',
    lat: -43.3,
    lon: -11.2,
    elev: 1200,
    temp: -45,
    rng: 260,
    rain: 0,
    press: 0,
    slope: 16,
    gravity: 1.62,
    use: 'Young Copernican complex impact crater with steep terraced walls, anorthositic central peak, and pooled impact-melt ponds.',
    vector: {
      geology: 0.85,
      terrain: computeTerrainAxis(16),
      thermal: computeThermalAxis(-45, 260),
      waterIce: 0.1,
      subsurface: 0.25,
      aeolian: 0.8,
      biosignature: 0.05,
      mobility: 0.45,
    },
  },
  {
    id: 'mars_jezero',
    name: 'Jezero Crater Delta',
    focus: 'Mars',
    region: 'Isidis region',
    lat: 18.4,
    lon: 77.7,
    elev: -2500,
    temp: -60,
    rng: 95,
    rain: 0,
    press: 0.7,
    slope: 5,
    gravity: 3.71,
    use: 'Perseverance landing site: ancient river delta on a basaltic crater floor with biosignature and sample-return goals.',
    vector: {
      geology: 0.85,
      terrain: computeTerrainAxis(5),
      thermal: computeThermalAxis(-60, 95),
      waterIce: 0.3,
      subsurface: 0.15,
      aeolian: 0.75,
      biosignature: 0.8,
      mobility: 0.7,
    },
  },
  {
    id: 'mars_utopia',
    name: 'Utopia Planitia Ice Plains',
    focus: 'Mars',
    region: 'Northern lowlands',
    lat: 47.0,
    lon: 118.0,
    elev: -4000,
    temp: -65,
    rng: 110,
    rain: 0,
    press: 0.9,
    slope: 2,
    gravity: 3.71,
    use: 'Human-mission candidate area: flat terrain with shallow ground ice for water resources.',
    vector: {
      geology: 0.55,
      terrain: computeTerrainAxis(2),
      thermal: computeThermalAxis(-65, 110),
      waterIce: 0.9,
      subsurface: 0.05,
      aeolian: 0.8,
      biosignature: 0.4,
      mobility: 0.85,
    },
  },
];

export const INITIAL_EARTH_ANALOG_SITES: EarthAnalogSite[] = [
  {
    id: 'atacama_yungay',
    name: 'Atacama Desert - Yungay',
    focus: 'Mars',
    region: 'Chile',
    lat: -24.1,
    lon: -69.9,
    elev: 1000,
    temp: 17,
    rng: 28,
    rain: 1,
    press: 90,
    slope: 3,
    solar: null,
    use: 'Hyper-arid soils at the limit of microbial life; used to test Mars life-detection instruments.',
    limits: 'Dryness and dust match well; temperature and ground ice are very different from Mars.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.45,
      terrain: computeTerrainAxis(3),
      thermal: computeThermalAxis(17, 28),
      waterIce: 0.05,
      subsurface: 0.05,
      aeolian: 0.75,
      biosignature: 0.8,
      mobility: 0.85,
    },
  },
  {
    id: 'dry_valleys',
    name: 'Antarctic Dry Valleys - Wright Valley',
    focus: 'Mars',
    region: 'Antarctica',
    lat: -77.5,
    lon: 161.5,
    elev: 400,
    temp: -20,
    rng: 50,
    rain: 15,
    press: 97,
    slope: 12,
    solar: null,
    use: 'Cold desert with ground ice and permafrost; a classic analog for Mars mid-latitude ice.',
    limits: 'Strong on cold and ground ice; far wetter and denser air than Mars.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.55,
      terrain: computeTerrainAxis(12),
      thermal: computeThermalAxis(-20, 50),
      waterIce: 0.85,
      subsurface: 0.1,
      aeolian: 0.4,
      biosignature: 0.65,
      mobility: 0.6,
    },
  },
  {
    id: 'mauna_loa_saddle',
    name: 'Mauna Loa Saddle Lava Fields',
    focus: 'Moon and Mars',
    region: 'Hawaii, USA',
    lat: 19.5,
    lon: -155.6,
    elev: 2000,
    temp: 10,
    rng: 20,
    rain: 500,
    press: 80,
    slope: 8,
    solar: null,
    use: 'Basaltic regolith and lava tubes for ISRU and construction trials.',
    limits: 'Excellent basalt and lava tubes; warm and humid compared with the Moon.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.95,
      terrain: computeTerrainAxis(8),
      thermal: computeThermalAxis(10, 20),
      waterIce: 0.05,
      subsurface: 0.85,
      aeolian: 0.35,
      biosignature: 0.25,
      mobility: 0.7,
    },
  },
  {
    id: 'lanzarote_timanfaya',
    name: 'Lanzarote - Timanfaya Lava Tubes',
    focus: 'Moon',
    region: 'Canary Islands, Spain',
    lat: 29.0,
    lon: -13.7,
    elev: 300,
    temp: 20,
    rng: 22,
    rain: 140,
    press: 100,
    slope: 8,
    solar: null,
    use: 'Accessible lava tubes for testing robotic exploration and habitat concepts relevant to lunar pits.',
    limits: 'Strong lava-tube and basalt match; mild temperature and a full atmosphere.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.9,
      terrain: computeTerrainAxis(8),
      thermal: computeThermalAxis(20, 22),
      waterIce: 0.05,
      subsurface: 0.9,
      aeolian: 0.3,
      biosignature: 0.2,
      mobility: 0.75,
    },
  },
  {
    id: 'stillwater_anorthosite',
    name: 'Stillwater Banded Anorthosite Zone',
    focus: 'Moon',
    region: 'Montana, USA',
    lat: 45.4,
    lon: -109.9,
    elev: 2740,
    temp: 2,
    rng: 32,
    rain: 540,
    press: 73,
    slope: 15,
    solar: null,
    use: 'High-calcium plagioclase anorthosite crust for testing lunar highlands oxygen ISRU and crater-rim rover traversability.',
    limits: 'Mineralogy matches lunar highlands closely, but terrestrial weathering and alpine precipitation differ from vacuum regolith.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.95,
      terrain: computeTerrainAxis(15),
      thermal: computeThermalAxis(2, 32),
      waterIce: 0.35,
      subsurface: 0.2,
      aeolian: 0.2,
      biosignature: 0.15,
      mobility: 0.55,
    },
  },
  {
    id: 'sudbury_melt_sheet',
    name: 'Sudbury Igneous Complex Melt Sheet',
    focus: 'Moon',
    region: 'Ontario, Canada',
    lat: 46.6,
    lon: -81.2,
    elev: 310,
    temp: 4,
    rng: 36,
    rain: 890,
    press: 98,
    slope: 9,
    solar: null,
    use: 'Preserved differentiated impact melt sheet and suevite breccia for training on lunar crater melt stratigraphy (Tycho & SPA).',
    limits: 'Boreal vegetation, glacial erosion, and higher silica content obscure original crater morphology.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.9,
      terrain: computeTerrainAxis(9),
      thermal: computeThermalAxis(4, 36),
      waterIce: 0.3,
      subsurface: 0.3,
      aeolian: 0.2,
      biosignature: 0.2,
      mobility: 0.65,
    },
  },
  {
    id: 'dasht_e_lut',
    name: 'Dasht-e Lut Yardang Desert',
    focus: 'Mars',
    region: 'Iran',
    lat: 30.5,
    lon: 58.3,
    elev: 400,
    temp: 28,
    rng: 50,
    rain: 30,
    press: 97,
    slope: 3,
    solar: null,
    use: 'Dunes and wind-carved yardangs for studying aeolian processes and rover mobility on sand.',
    limits: 'Good for wind and dust processes; far too hot.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.35,
      terrain: computeTerrainAxis(3),
      thermal: computeThermalAxis(28, 50),
      waterIce: 0.05,
      subsurface: 0.05,
      aeolian: 0.9,
      biosignature: 0.25,
      mobility: 0.6,
    },
  },
  {
    id: 'kharan_chagai',
    name: 'Kharan-Chagai Desert (hypothesis)',
    focus: 'Mars',
    region: 'Balochistan, Pakistan',
    lat: 28.9,
    lon: 64.6,
    elev: 800,
    temp: 23,
    rng: 45,
    rain: 80,
    press: 92,
    slope: 4,
    solar: null,
    use: 'Under-studied candidate: dry basin with dunes and volcanic terrain nearby. Needs real data to confirm or reject.',
    limits: 'Unverified: geology scores are estimates; test with NASA data before claiming a match.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.6,
      terrain: computeTerrainAxis(4),
      thermal: computeThermalAxis(23, 45),
      waterIce: 0.05,
      subsurface: 0.05,
      aeolian: 0.85,
      biosignature: 0.2,
      mobility: 0.7,
    },
  },
  {
    id: 'qaidam_basin',
    name: 'Qaidam Basin Salt Yardangs',
    focus: 'Mars',
    region: 'China',
    lat: 37.5,
    lon: 93.5,
    elev: 2900,
    temp: 4,
    rng: 45,
    rain: 40,
    press: 71,
    slope: 3,
    solar: null,
    use: 'Cold high-altitude salt basin with yardangs; reduced pressure and strong UV.',
    limits: 'Good for cold and thin air; still far denser than Mars.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.5,
      terrain: computeTerrainAxis(3),
      thermal: computeThermalAxis(4, 45),
      waterIce: 0.15,
      subsurface: 0.05,
      aeolian: 0.85,
      biosignature: 0.45,
      mobility: 0.75,
    },
  },
  {
    id: 'haughton_crater',
    name: 'Haughton Impact Structure',
    focus: 'Moon and Mars',
    region: 'Devon Island, Canada',
    lat: 75.4,
    lon: -89.7,
    elev: 30,
    temp: -16,
    rng: 55,
    rain: 150,
    press: 101,
    slope: 6,
    solar: null,
    use: 'Polar impact crater with ground ice; long-running Moon and Mars field-operations testing.',
    limits: 'Cold and ice match well; low in basalt, with a much denser and wetter atmosphere.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.65,
      terrain: computeTerrainAxis(6),
      thermal: computeThermalAxis(-16, 55),
      waterIce: 0.85,
      subsurface: 0.1,
      aeolian: 0.4,
      biosignature: 0.5,
      mobility: 0.55,
    },
  },
  {
    id: 'danakil_depression',
    name: 'Danakil Depression',
    focus: 'Mars',
    region: 'Ethiopia',
    lat: 14.2,
    lon: 40.3,
    elev: -100,
    temp: 34,
    rng: 25,
    rain: 100,
    press: 101,
    slope: 3,
    solar: null,
    use: 'Hydrothermal and volcanic terrain for studying water-rock alteration and extreme-life habitats.',
    limits: 'Strong on volcanic and hydrothermal processes; much too hot.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.8,
      terrain: computeTerrainAxis(3),
      thermal: computeThermalAxis(34, 25),
      waterIce: 0.2,
      subsurface: 0.25,
      aeolian: 0.4,
      biosignature: 0.85,
      mobility: 0.4,
    },
  },
  {
    id: 'puna_de_atacama',
    name: 'Puna de Atacama Volcanic Plateau',
    focus: 'Mars',
    region: 'Chile / Argentina',
    lat: -25.5,
    lon: -67.6,
    elev: 3900,
    temp: 6,
    rng: 30,
    rain: 100,
    press: 62,
    slope: 10,
    solar: null,
    use: 'High volcanic plateau with thin air and strong UV; testing of instruments and operations at altitude.',
    limits: 'Thin air and volcanic terrain help; still about 60 times denser than Mars air.',
    src: 'Estimate (literature-based)',
    nasaLoaded: false,
    vector: {
      geology: 0.7,
      terrain: computeTerrainAxis(10),
      thermal: computeThermalAxis(6, 30),
      waterIce: 0.2,
      subsurface: 0.1,
      aeolian: 0.6,
      biosignature: 0.7,
      mobility: 0.55,
    },
  },
];

export interface SimilarityResult {
  site: EarthAnalogSite;
  target: PlanetaryTargetSite;
  combinedScore: number;
  cosineSimilarity: number;
  euclideanSimilarity: number;
  matchClass: 'High Fidelity' | 'Partial Match' | 'Low Fidelity';
}

export function computeWeightedSimilarity(
  site: EarthAnalogSite,
  target: PlanetaryTargetSite,
  weights: DimensionWeights
): SimilarityResult {
  const keys = ANALOG_DIMENSIONS.map((d) => d.key);
  let sw = 0;
  let sd = 0;
  let dot = 0;
  let na = 0;
  let nb = 0;

  for (const key of keys) {
    const w = weights[key];
    const a = site.vector[key] * 100;
    const b = target.vector[key] * 100;
    sw += w;
    sd += w * (a - b) * (a - b);
    dot += w * a * b;
    na += w * a * a;
    nb += w * b * b;
  }

  sw = sw || 1;
  const euc = 100 - Math.sqrt(sd / sw);
  const cos = (100 * dot) / (Math.sqrt(na * nb) || 1);
  const match = 0.4 * cos + 0.6 * euc;

  const matchClass: SimilarityResult['matchClass'] =
    match >= 80
      ? 'High Fidelity'
      : match >= 65
      ? 'Partial Match'
      : 'Low Fidelity';

  return {
    site,
    target,
    combinedScore: match,
    cosineSimilarity: cos,
    euclideanSimilarity: euc,
    matchClass,
  };
}

export function rankAnalogsForTarget(
  sites: EarthAnalogSite[],
  targetId: string,
  weights: DimensionWeights,
  bodyFilter: 'All' | 'Moon' | 'Mars' = 'All'
): SimilarityResult[] {
  const target =
    PLANETARY_TARGETS.find((t) => t.id === targetId) ?? PLANETARY_TARGETS[0];

  return sites
    .filter((site) => {
      if (bodyFilter === 'All') return true;
      return site.focus.includes(bodyFilter);
    })
    .map((site) => computeWeightedSimilarity(site, target, weights))
    .sort((a, b) => b.combinedScore - a.combinedScore);
}

export function buildCsvExport(results: SimilarityResult[]): string {
  const headers = [
    'rank',
    'site',
    'region',
    'focus',
    'match_percent',
    'cosine',
    'euclidean',
    'mean_temp_c',
    'temp_range_c',
    'rain_mm_yr',
    'pressure_kpa',
    'slope_deg',
    'data_source',
  ];

  const q = (v: unknown) => `"${String(v).replace(/"/g, '""')}"`;

  const rows = results.map((r, idx) =>
    [
      idx + 1,
      r.site.name,
      r.site.region,
      r.site.focus,
      r.combinedScore.toFixed(1),
      r.cosineSimilarity.toFixed(1),
      r.euclideanSimilarity.toFixed(1),
      r.site.temp,
      r.site.rng,
      r.site.rain,
      r.site.press,
      r.site.slope,
      r.site.src,
    ]
      .map(q)
      .join(',')
  );

  return [headers.join(','), ...rows].join('\n');
}

const MONTHS = [
  'JAN',
  'FEB',
  'MAR',
  'APR',
  'MAY',
  'JUN',
  'JUL',
  'AUG',
  'SEP',
  'OCT',
  'NOV',
  'DEC',
] as const;

export interface NasaPowerObservation {
  temp: number;
  rng: number;
  rain: number;
  press: number;
  solar: number | null;
}

export async function fetchNasaPowerPoint(
  lat: number,
  lon: number,
  includeSolar = false
): Promise<NasaPowerObservation> {
  const params = includeSolar
    ? 'T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,PS,ALLSKY_SFC_SW_DWN'
    : 'T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,PS';

  const url = `https://power.larc.nasa.gov/api/temporal/climatology/point?parameters=${params}&community=RE&latitude=${lat.toFixed(
    3
  )}&longitude=${lon.toFixed(3)}&format=JSON`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`NASA POWER HTTP ${res.status}`);
  }
  const json = await res.json();
  const p = json?.properties?.parameter;
  if (!p) throw new Error('Invalid NASA POWER response');

  const temp = Number(p.T2M?.ANN);
  const maxTemps = MONTHS.map((m) => Number(p.T2M_MAX?.[m]));
  const minTemps = MONTHS.map((m) => Number(p.T2M_MIN?.[m]));
  const rng = Math.max(...maxTemps) - Math.min(...minTemps);
  const rain = Number(p.PRECTOTCORR?.ANN) * 365.25;
  const press = Number(p.PS?.ANN);

  if ([temp, rng, rain, press].some((v) => !Number.isFinite(v) || v <= -900)) {
    throw new Error('Missing NASA POWER values');
  }

  let solar: number | null = null;
  if (includeSolar && p.ALLSKY_SFC_SW_DWN?.ANN != null) {
    const s = Number(p.ALLSKY_SFC_SW_DWN.ANN);
    if (Number.isFinite(s) && s > 0) {
      solar = Math.round(s * 10) / 10;
    }
  }

  return {
    temp: Math.round(temp * 10) / 10,
    rng: Math.round(rng * 10) / 10,
    rain: Math.round(rain * 10) / 10,
    press: Math.round(press * 10) / 10,
    solar,
  };
}

export function haversineKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const r = Math.PI / 180;
  const x =
    Math.sin(((lat2 - lat1) * r) / 2) ** 2 +
    Math.cos(lat1 * r) *
      Math.cos(lat2 * r) *
      Math.sin(((lon2 - lon1) * r) / 2) ** 2;
  return 12742 * Math.asin(Math.sqrt(x));
}

export function computeClimateMatchScore(
  obs: Pick<NasaPowerObservation, 'temp' | 'rng' | 'rain' | 'press'>,
  target: PlanetaryTargetSite,
  earthSites: EarthAnalogSite[]
): number {
  const keys = ['temp', 'rng', 'rain', 'press'] as const;
  let score = 0;
  for (const k of keys) {
    const vals = earthSites.map((e) => e[k]);
    const span = Math.max(...vals) - Math.min(...vals) || 1;
    score += 1 - Math.min(1, Math.abs(obs[k] - target[k]) / span);
  }
  return 25 * score;
}

export function classifyClimate(
  obs: Pick<NasaPowerObservation, 'temp' | 'rain'>
): string {
  if (obs.temp < -10) return 'Polar / ice desert';
  if (obs.rain < 250) {
    return obs.temp > 18 ? 'Hot desert' : 'Cold desert or steppe';
  }
  if (obs.temp < 5) return 'Cold highland or tundra';
  return 'Temperate or humid region';
}
