import React, { useState } from 'react';
import {
  ANALOG_DIMENSIONS,
  AnalogDimensionKey,
  DimensionVector,
} from '../data/planetaryAnalogs';

interface RadarComparisonChartProps {
  earthName: string;
  targetName: string;
  earthVector: DimensionVector;
  targetVector: DimensionVector;
  secondaryEarthName?: string;
  secondaryEarthVector?: DimensionVector;
  size?: number;
}

export const RadarComparisonChart: React.FC<RadarComparisonChartProps> = ({
  earthName,
  targetName,
  earthVector,
  targetVector,
  secondaryEarthName,
  secondaryEarthVector,
  size = 330,
}) => {
  const [hoveredAxis, setHoveredAxis] = useState<AnalogDimensionKey | null>(null);

  const cx = size / 2;
  const cy = size / 2;
  const maxRadius = size * 0.34;
  const levels = [0.25, 0.5, 0.75, 1.0];
  const axisCount = ANALOG_DIMENSIONS.length;

  const getPoint = (index: number, value: number) => {
    const angle = (Math.PI * 2 * index) / axisCount - Math.PI / 2;
    const r = maxRadius * Math.max(0, Math.min(1, value));
    return {
      x: cx + r * Math.cos(angle),
      y: cy + r * Math.sin(angle),
      labelX: cx + (maxRadius + 28) * Math.cos(angle),
      labelY: cy + (maxRadius + 24) * Math.sin(angle),
    };
  };

  const buildPolygonPoints = (vec: DimensionVector) =>
    ANALOG_DIMENSIONS.map((dim, idx) => {
      const pt = getPoint(idx, vec[dim.key]);
      return `${pt.x.toFixed(1)},${pt.y.toFixed(1)}`;
    }).join(' ');

  const earthPoints = buildPolygonPoints(earthVector);
  const secondaryEarthPoints = secondaryEarthVector
    ? buildPolygonPoints(secondaryEarthVector)
    : null;
  const targetPoints = buildPolygonPoints(targetVector);

  const activeDim = hoveredAxis
    ? ANALOG_DIMENSIONS.find((d) => d.key === hoveredAxis) ?? null
    : null;

  return (
    <div className="flex flex-col items-center">
      <div className="flex flex-wrap items-center justify-between w-full mb-2 gap-2 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-1.5 text-cyan-300">
            <span className="inline-block w-3 h-0.5 bg-cyan-400" />
            <span className="truncate max-w-[160px]">
              {secondaryEarthVector ? `Site A: ${earthName}` : earthName}
            </span>
          </div>
          {secondaryEarthName && secondaryEarthVector && (
            <div className="flex items-center gap-1.5 text-emerald-300">
              <span className="inline-block w-3 h-0.5 bg-emerald-400" />
              <span className="truncate max-w-[160px]">
                Site B: {secondaryEarthName}
              </span>
            </div>
          )}
          <div className="flex items-center gap-1.5 text-amber-300">
            <span className="inline-block w-3 h-0.5 bg-amber-400 border-t border-dashed border-amber-300" />
            <span className="truncate max-w-[160px]">{targetName}</span>
          </div>
        </div>
      </div>

      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="w-full max-w-[330px] h-auto overflow-visible select-none"
        role="img"
        aria-label={`8-axis similarity radar comparing ${earthName}${
          secondaryEarthName ? `, ${secondaryEarthName},` : ''
        } and ${targetName}`}
      >
        {/* Concentric octagonal rings */}
        {levels.map((lvl) => {
          const ringPts = ANALOG_DIMENSIONS.map((_, idx) => {
            const p = getPoint(idx, lvl);
            return `${p.x.toFixed(1)},${p.y.toFixed(1)}`;
          }).join(' ');
          return (
            <polygon
              key={lvl}
              points={ringPts}
              fill="none"
              stroke="#1e293b"
              strokeWidth={lvl === 1 ? 1.25 : 0.85}
            />
          );
        })}

        {/* Radial spoke lines */}
        {ANALOG_DIMENSIONS.map((dim, idx) => {
          const outer = getPoint(idx, 1);
          const isHovered = hoveredAxis === dim.key;
          return (
            <line
              key={dim.key}
              x1={cx}
              y1={cy}
              x2={outer.x}
              y2={outer.y}
              stroke={isHovered ? '#38bdf8' : '#1e293b'}
              strokeWidth={isHovered ? 1.4 : 0.9}
            />
          );
        })}

        {/* Ring numeric labels */}
        {[0.5, 1.0].map((lvl) => (
          <text
            key={lvl}
            x={cx + 4}
            y={cy - maxRadius * lvl + 10}
            fill="#64748b"
            fontSize="9"
            fontFamily="JetBrains Mono, monospace"
          >
            {(lvl * 100).toFixed(0)}
          </text>
        ))}

        {/* Target Moon/Mars polygon */}
        <polygon
          points={targetPoints}
          fill="rgba(245, 158, 11, 0.12)"
          stroke="#f59e0b"
          strokeWidth={1.75}
          strokeDasharray="4 3"
        />

        {/* Optional Secondary Earth Analog (Site B) polygon */}
        {secondaryEarthPoints && (
          <polygon
            points={secondaryEarthPoints}
            fill="rgba(16, 185, 129, 0.16)"
            stroke="#10b981"
            strokeWidth={2}
          />
        )}

        {/* Primary Earth Analog (Site A) polygon */}
        <polygon
          points={earthPoints}
          fill="rgba(6, 182, 212, 0.20)"
          stroke="#06b6d4"
          strokeWidth={2}
        />

        {/* Data vertices + hover hit targets */}
        {ANALOG_DIMENSIONS.map((dim, idx) => {
          const ePt = getPoint(idx, earthVector[dim.key]);
          const sPt = secondaryEarthVector
            ? getPoint(idx, secondaryEarthVector[dim.key])
            : null;
          const tPt = getPoint(idx, targetVector[dim.key]);
          const outer = getPoint(idx, 1);
          const isHovered = hoveredAxis === dim.key;

          let textAnchor: 'middle' | 'start' | 'end' = 'middle';
          if (outer.labelX > cx + 14) textAnchor = 'start';
          else if (outer.labelX < cx - 14) textAnchor = 'end';

          return (
            <g
              key={dim.key}
              className="cursor-pointer"
              onMouseEnter={() => setHoveredAxis(dim.key)}
              onMouseLeave={() => setHoveredAxis(null)}
            >
              <circle
                cx={tPt.x}
                cy={tPt.y}
                r={isHovered ? 4 : 2.5}
                fill="#f59e0b"
              />
              {sPt && (
                <circle
                  cx={sPt.x}
                  cy={sPt.y}
                  r={isHovered ? 4.5 : 3}
                  fill="#10b981"
                  stroke="#07090e"
                  strokeWidth={1}
                />
              )}
              <circle
                cx={ePt.x}
                cy={ePt.y}
                r={isHovered ? 4.5 : 3}
                fill="#06b6d4"
                stroke="#07090e"
                strokeWidth={1}
              />
              <text
                x={outer.labelX}
                y={outer.labelY}
                textAnchor={textAnchor}
                dominantBaseline="middle"
                fill={isHovered ? '#22d3ee' : '#94a3b8'}
                fontSize="10"
                fontFamily="JetBrains Mono, monospace"
                fontWeight={isHovered ? '600' : '400'}
              >
                {dim.shortLabel}
              </text>
              <circle cx={outer.labelX} cy={outer.labelY} r={18} fill="transparent" />
            </g>
          );
        })}
      </svg>

      {/* Axis inspection readout */}
      <div className="w-full mt-2 px-3 py-2 bg-[#0B0F19] border border-slate-800 rounded text-xs font-mono tabular-nums flex flex-wrap items-center justify-between gap-2 min-h-[38px]">
        {activeDim ? (
          <>
            <span className="text-slate-200 font-medium">{activeDim.label}</span>
            <span className="text-slate-400">
              {secondaryEarthVector ? 'A ' : 'Earth '}
              <strong className="text-cyan-400">
                {(earthVector[activeDim.key] * 100).toFixed(0)}
              </strong>{' '}
              {secondaryEarthVector && (
                <>
                  · B{' '}
                  <strong className="text-emerald-400">
                    {(secondaryEarthVector[activeDim.key] * 100).toFixed(0)}
                  </strong>{' '}
                </>
              )}
              · Target{' '}
              <strong className="text-amber-400">
                {(targetVector[activeDim.key] * 100).toFixed(0)}
              </strong>{' '}
              {!secondaryEarthVector && (
                <>
                  · Δ{' '}
                  <strong className="text-slate-200">
                    {(
                      Math.abs(
                        earthVector[activeDim.key] - targetVector[activeDim.key]
                      ) * 100
                    ).toFixed(0)}
                  </strong>
                </>
              )}
            </span>
          </>
        ) : (
          <span className="text-slate-500">
            Hover any radar vertex to inspect {secondaryEarthVector ? 'Site A, Site B, and target' : 'Earth vs. planetary target'} scores.
          </span>
        )}
      </div>
    </div>
  );
};
