import React from 'react';
import { PLANETARY_TARGETS } from '../data/planetaryAnalogs';
import earthImg from '../assets/images/earth_planet_orbit_1794672604590.jpg';
import moonImg from '../assets/images/moon_lunar_orbit_1794672605116.jpg';
import marsImg from '../assets/images/mars_red_planet_1794672605782.jpg';
import mercuryImg from '../assets/images/mercury_planet_orbit_1794672945404.jpg';
import venusImg from '../assets/images/venus_planet_orbit_1794672946574.jpg';
import jupiterImg from '../assets/images/jupiter_planet_orbit_1794672948392.jpg';
import saturnImg from '../assets/images/saturn_rings_orbit_1794672947930.jpg';
import uranusImg from '../assets/images/uranus_planet_orbit_1794672948398.jpg';
import neptuneImg from '../assets/images/neptune_planet_orbit_1794672948805.jpg';

interface MoonAndMarsViewProps {
  onSelectTargetAndExplore: (targetId: string) => void;
}

const PLANET_CARDS = [
  {
    name: 'Earth',
    subtitle: 'Terrestrial Analog Baseline · 9.81 m/s²',
    image: earthImg,
    alt: 'Full view of planet Earth from orbit',
    accent: 'text-emerald-400',
  },
  {
    name: 'The Moon',
    subtitle: 'Lunar South Pole & Lava Tubes · 1.62 m/s²',
    image: moonImg,
    alt: 'Full view of the Moon from orbit',
    accent: 'text-cyan-400',
  },
  {
    name: 'Mars',
    subtitle: 'Jezero Crater & Ice Plains · 3.71 m/s²',
    image: marsImg,
    alt: 'Full view of planet Mars from orbit',
    accent: 'text-amber-400',
  },
];

const OTHER_PLANETS = [
  {
    name: 'Mercury',
    type: 'Terrestrial Planet',
    gravity: '3.70 m/s²',
    temp: '-180 to +430 °C',
    note: 'Airless cratered silicate crust, structurally akin to lunar highlands.',
    image: mercuryImg,
  },
  {
    name: 'Venus',
    type: 'Terrestrial Planet',
    gravity: '8.87 m/s²',
    temp: '+465 °C mean',
    note: 'Dense 92 bar CO₂ greenhouse atmosphere and volcanic basalt plains.',
    image: venusImg,
  },
  {
    name: 'Jupiter',
    type: 'Gas Giant',
    gravity: '24.79 m/s²',
    temp: '-110 °C cloud tops',
    note: 'Largest planet; icy moons Europa & Ganymede harbor subsurface oceans.',
    image: jupiterImg,
  },
  {
    name: 'Saturn',
    type: 'Gas Giant',
    gravity: '10.44 m/s²',
    temp: '-140 °C cloud tops',
    note: 'Icy ring system; moon Titan hosts liquid hydrocarbon lakes & thick N₂ air.',
    image: saturnImg,
  },
  {
    name: 'Uranus',
    type: 'Ice Giant',
    gravity: '8.69 m/s²',
    temp: '-195 °C cloud tops',
    note: '98° axial tilt with methane haze and water-ammonia-methane interior.',
    image: uranusImg,
  },
  {
    name: 'Neptune',
    type: 'Ice Giant',
    gravity: '11.15 m/s²',
    temp: '-200 °C cloud tops',
    note: 'Supersonic winds up to 2,100 km/h and cryovolcanic moon Triton.',
    image: neptuneImg,
  },
];

const WORLD_COMPARISON = [
  {
    metric: 'Mean radius',
    earth: '6,371 km',
    moon: '1,737 km',
    mars: '3,390 km',
  },
  {
    metric: 'Surface gravity',
    earth: '9.81 m/s²',
    moon: '1.62 m/s² (about 17% of Earth)',
    mars: '3.71 m/s² (about 38% of Earth)',
  },
  {
    metric: 'Atmosphere',
    earth: 'about 101 kPa, nitrogen and oxygen',
    moon: 'Near vacuum',
    mars: 'about 0.6 kPa, about 95% carbon dioxide',
  },
  {
    metric: 'Surface temperature',
    earth: 'about 15 °C average',
    moon: 'about -173 to +127 °C over one lunar day; colder in polar shadow',
    mars: 'about -140 to +20 °C; mean near -60 °C',
  },
  {
    metric: 'Day length',
    earth: '24 hours',
    moon: 'about 29.5 Earth days (day plus night)',
    mars: 'about 24 h 37 min',
  },
  {
    metric: 'Distance and signal delay',
    earth: '—',
    moon: 'about 384,000 km; about 1.3 s one way',
    mars: '55 to 400 million km; about 3 to 22 min one way',
  },
  {
    metric: 'Magnetic field',
    earth: 'Strong, global',
    moon: 'None global',
    mars: 'None global (patchy crustal fields)',
  },
  {
    metric: 'Water',
    earth: 'Abundant liquid water',
    moon: 'Ice in permanently shadowed polar craters',
    mars: 'Polar ice caps and buried mid-latitude ice',
  },
  {
    metric: 'Dust and soil',
    earth: 'Weathered soil',
    moon: 'Sharp, abrasive regolith that clings by static charge',
    mars: 'Fine dust, global dust storms, perchlorate salts',
  },
];

export const MoonAndMarsView: React.FC<MoonAndMarsViewProps> = ({
  onSelectTargetAndExplore,
}) => {
  return (
    <div className="max-w-[1120px] mx-auto px-6 py-8 space-y-6">
      {/* Primary Analog Worlds (Full Uncropped Globes) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PLANET_CARDS.map((planet) => (
          <div
            key={planet.name}
            className="bg-[#0B0F19] border border-slate-800 rounded overflow-hidden"
          >
            <div className="aspect-video w-full bg-black overflow-hidden p-2 flex items-center justify-center">
              <img
                src={planet.image}
                alt={planet.alt}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="p-3.5 border-t border-slate-800/80">
              <div className={`text-sm font-semibold ${planet.accent}`}>
                {planet.name}
              </div>
              <div className="text-xs font-mono text-slate-400 mt-0.5">
                {planet.subtitle}
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Other Solar System Planets */}
      <section className="bg-[#0B0F19] border border-slate-800 rounded p-5 space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">
            Other Solar System Planets
          </h2>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Planetary context across terrestrial worlds, gas giants, and ice giants
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {OTHER_PLANETS.map((planet) => (
            <div
              key={planet.name}
              className="bg-[#07090E] border border-slate-800 rounded overflow-hidden flex flex-col"
            >
              <div className="aspect-video w-full bg-black overflow-hidden p-2 flex items-center justify-center">
                <img
                  src={planet.image}
                  alt={`Full view of planet ${planet.name}`}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="p-3.5 space-y-1.5 border-t border-slate-800/80 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-semibold text-slate-100">
                    {planet.name}
                  </span>
                  <span className="text-[11px] font-mono text-cyan-400">
                    {planet.type}
                  </span>
                </div>
                <div className="text-[11px] font-mono tabular-nums text-slate-400">
                  Gravity {planet.gravity} · {planet.temp}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pt-0.5">
                  {planet.note}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Three Worlds Compared */}
      <section className="bg-[#0B0F19] border border-slate-800 rounded p-5 space-y-3">
        <div>
          <h2 className="text-xl font-semibold text-slate-100">
            Three worlds compared
          </h2>
          <p className="text-xs font-mono text-slate-400 mt-1">
            The conditions every Earth analog is judged against
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono">
                <th className="py-2.5 px-3" />
                <th className="py-2.5 px-3 text-slate-200">Earth</th>
                <th className="py-2.5 px-3 text-cyan-400">Moon</th>
                <th className="py-2.5 px-3 text-amber-400">Mars</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {WORLD_COMPARISON.map((row) => (
                <tr key={row.metric} className="hover:bg-slate-900/40">
                  <td className="py-2.5 px-3 font-medium text-slate-300 whitespace-nowrap">
                    {row.metric}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">{row.earth}</td>
                  <td className="py-2.5 px-3 text-slate-300">{row.moon}</td>
                  <td className="py-2.5 px-3 text-slate-300">{row.mars}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* The Moon & Mars Overview Cards */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-[#0B0F19] border border-slate-800 rounded p-5 space-y-2.5">
          <h2 className="text-lg font-semibold text-cyan-400">The Moon</h2>
          <p className="text-xs text-slate-400">
            Why go: the nearest destination (about three days), a place to test everything before Mars.
          </p>
          <ul className="space-y-1.5 text-xs text-slate-300 list-disc pl-4 leading-relaxed">
            <li>
              Candidate permanent base near the south pole: long sunlight on ridge crests, water ice in nearby shadowed craters.
            </li>
            <li>
              Lava tubes and pits could shelter crews from radiation and temperature swings.
            </li>
            <li>
              Challenges: two-week nights, abrasive dust, no atmosphere or magnetic field, micrometeorites.
            </li>
            <li>
              Earth analogs help test: regolith handling, lava-tube robotics, polar operations, ice mining.
            </li>
          </ul>
        </div>

        <div className="bg-[#0B0F19] border border-slate-800 rounded p-5 space-y-2.5">
          <h2 className="text-lg font-semibold text-amber-400">Mars</h2>
          <p className="text-xs text-slate-400">
            Why go: the best place to search for past life and a long-term human destination.
          </p>
          <ul className="space-y-1.5 text-xs text-slate-300 list-disc pl-4 leading-relaxed">
            <li>
              Ancient river deltas such as Jezero Crater preserve rocks that may hold biosignatures.
            </li>
            <li>
              Shallow ground ice in the mid-latitudes could supply water.
            </li>
            <li>
              Challenges: thin air makes landing hard, perchlorate dust, dust storms, long communication delay, radiation (rover measurements near 0.6 to 0.7 mSv per day).
            </li>
            <li>
              Earth analogs help test: life detection, rover mobility on dunes and slopes, ice drilling, hydrothermal systems.
            </li>
          </ul>
        </div>
      </section>

      {/* Candidate Target Sites */}
      <section className="bg-[#0B0F19] border border-slate-800 rounded p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold text-slate-100">
            Candidate target sites
          </h2>
          <span className="text-xs font-mono text-slate-400">
            5 Moon targets · 2 Mars targets
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {PLANETARY_TARGETS.map((t) => (
            <div
              key={t.id}
              className="bg-[#07090E] border border-slate-800 rounded overflow-hidden flex flex-col justify-between"
            >
              <div>
                <div className="aspect-video w-full bg-black overflow-hidden border-b border-slate-800/80 p-1.5 flex items-center justify-center">
                  <img
                    src={t.focus === 'Moon' ? moonImg : marsImg}
                    alt={`Full view of ${t.focus} for ${t.name}`}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="p-4 space-y-2">
                  <div className="text-xs font-mono text-slate-400">
                    <span
                      className={
                        t.focus === 'Moon' ? 'text-cyan-400' : 'text-amber-400'
                      }
                    >
                      {t.focus}
                    </span>{' '}
                    · {t.region}
                  </div>
                  <div className="text-sm font-semibold text-slate-100">
                    {t.name}
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {t.use}
                  </p>
                </div>
              </div>

              <div className="px-4 pb-4 space-y-2 pt-2 border-t border-slate-800/80">
                <div className="grid grid-cols-2 gap-1 text-[11px] font-mono tabular-nums text-slate-400">
                  <span>Temp {t.temp} °C</span>
                  <span>Swing {t.rng} °C</span>
                  <span>Gravity {t.gravity} m/s²</span>
                  <span>Air {t.press} kPa</span>
                  <span>
                    {t.lat.toFixed(1)}°, {t.lon.toFixed(1)}°
                  </span>
                  <span>Slope {t.slope}°</span>
                </div>

                <button
                  type="button"
                  onClick={() => onSelectTargetAndExplore(t.id)}
                  className="w-full py-2 text-xs font-medium rounded border border-slate-700 text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Find Earth analogs
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
