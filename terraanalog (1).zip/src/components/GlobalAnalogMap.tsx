/// <reference types="google.maps" />
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {
  AdvancedMarker,
  APILoadingStatus,
  InfoWindow,
  Map as GoogleMap,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  classifyClimate,
  computeClimateMatchScore,
  EarthAnalogSite,
  fetchNasaPowerPoint,
  haversineKm,
  NasaPowerObservation,
  PlanetaryTargetSite,
  SimilarityResult,
} from '../data/planetaryAnalogs';

const Z_INDEX_SELECTED = 1000;
const Z_INDEX_HOVER = 999;

function scoreToColor(t: number): string {
  const hue = Math.max(0, Math.min(1, t)) * 120;
  return `hsl(${Math.round(hue)}, 75%, 45%)`;
}

interface AnalogMarkerItemProps {
  result: SimilarityResult;
  color: string;
  zIndex: number;
  isSelected: boolean;
  onSelect: (
    siteId: string,
    marker: google.maps.marker.AdvancedMarkerElement
  ) => void;
  onHoverChange: (siteId: string | null) => void;
}

const AnalogMarkerItem: React.FC<AnalogMarkerItemProps> = ({
  result,
  color,
  zIndex,
  isSelected,
  onSelect,
  onHoverChange,
}) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const { site } = result;

  return (
    <AdvancedMarker
      ref={markerRef}
      position={{ lat: site.lat, lng: site.lon }}
      zIndex={zIndex}
      title={`${site.name} (${result.combinedScore.toFixed(1)}%)`}
      onMouseEnter={() => onHoverChange(site.id)}
      onMouseLeave={() => onHoverChange(null)}
      onClick={() => {
        if (marker) onSelect(site.id, marker);
      }}
    >
      <div
        className="rounded-full border-2 border-white shadow-md transition-transform"
        style={{
          width: isSelected ? 22 : 18,
          height: isSelected ? 22 : 18,
          backgroundColor: color,
          boxShadow: isSelected
            ? '0 0 0 3px rgba(34, 211, 238, 0.75)'
            : '0 2px 6px rgba(0, 0, 0, 0.45)',
        }}
      />
    </AdvancedMarker>
  );
};

interface MapCameraSyncProps {
  selectedSite: EarthAnalogSite;
  mapTypeId: 'satellite' | 'terrain' | 'hybrid';
  flyTrigger: number;
}

const MapCameraSync: React.FC<MapCameraSyncProps> = ({
  selectedSite,
  mapTypeId,
  flyTrigger,
}) => {
  const map = useMap();

  useEffect(() => {
    if (!map) return;
    map.setMapTypeId(mapTypeId);
  }, [map, mapTypeId]);

  useEffect(() => {
    if (!map || flyTrigger === 0) return;
    map.panTo({ lat: selectedSite.lat, lng: selectedSite.lon });
    map.setZoom(5);
  }, [map, selectedSite.lat, selectedSite.lon, flyTrigger]);

  return null;
};

interface CursorInspection {
  lat: number;
  lon: number;
  country: string;
  loading: boolean;
  error?: string;
  climateType?: string;
  climateScore?: number;
  category?: { label: string; color: string };
  obs?: NasaPowerObservation;
}

interface CachedLookup {
  country: string;
  obs?: NasaPowerObservation;
  error?: string;
}

async function resolveCountryName(
  lat: number,
  lon: number,
  geocodingLib: google.maps.GeocodingLibrary | null
): Promise<string> {
  if (geocodingLib) {
    try {
      const geocoder = new geocodingLib.Geocoder();
      const resp = await geocoder.geocode({ location: { lat, lng: lon } });
      const results = resp.results ?? [];
      for (const r of results) {
        const countryComp = r.address_components?.find((c) =>
          c.types.includes('country')
        );
        if (countryComp?.long_name) {
          return countryComp.long_name;
        }
      }
    } catch {
      // Fallback below
    }
  }

  try {
    const res = await fetch(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat.toFixed(
        3
      )}&longitude=${lon.toFixed(3)}&localityLanguage=en`
    );
    if (res.ok) {
      const data = await res.json();
      if (data?.countryName) return String(data.countryName);
      if (data?.locality) return String(data.locality);
    }
  } catch {
    // Ignore network error
  }

  return 'Ocean / Unmapped Region';
}

interface MapCursorTrackerProps {
  allEarthSites: EarthAnalogSite[];
  activeTarget: PlanetaryTargetSite;
  onUpdateCursor: (info: CursorInspection | null) => void;
}

const MapCursorTracker: React.FC<MapCursorTrackerProps> = ({
  allEarthSites,
  activeTarget,
  onUpdateCursor,
}) => {
  const map = useMap();
  const geocodingLib = useMapsLibrary('geocoding');
  const cacheRef = useRef<Map<string, CachedLookup>>(new Map());
  const timerRef = useRef<number | null>(null);
  const seqRef = useRef(0);

  const scoreObs = useCallback(
    (obs: NasaPowerObservation) => {
      const sc = computeClimateMatchScore(obs, activeTarget, allEarthSites);
      const allScores = allEarthSites.map((e) =>
        computeClimateMatchScore(e, activeTarget, allEarthSites)
      );
      const pct =
        allScores.filter((x) => x <= sc).length /
        Math.max(1, allScores.length);

      const category =
        pct >= 0.67
          ? { label: 'Strong analog', color: '#16a34a' }
          : pct >= 0.34
          ? { label: 'Moderate analog', color: '#d97706' }
          : { label: 'Weak analog', color: '#dc2626' };

      return { sc, category, climateType: classifyClimate(obs) };
    },
    [activeTarget, allEarthSites]
  );

  useEffect(() => {
    if (!map) return;

    const moveListener = map.addListener(
      'mousemove',
      (e: google.maps.MapMouseEvent) => {
        if (!e.latLng) return;
        const lat = e.latLng.lat();
        const lon = ((e.latLng.lng() + 540) % 360) - 180;
        const cacheKey = `${(Math.round(lat * 4) / 4).toFixed(2)},${(
          Math.round(lon * 4) / 4
        ).toFixed(2)}`;

        const cached = cacheRef.current.get(cacheKey);
        if (cached) {
          if (timerRef.current) window.clearTimeout(timerRef.current);
          if (cached.obs) {
            const { sc, category, climateType } = scoreObs(cached.obs);
            onUpdateCursor({
              lat,
              lon,
              country: cached.country,
              loading: false,
              obs: cached.obs,
              climateType,
              climateScore: sc,
              category,
            });
          } else {
            onUpdateCursor({
              lat,
              lon,
              country: cached.country,
              loading: false,
              error: cached.error ?? 'Ocean / no land climate data',
            });
          }
          return;
        }

        onUpdateCursor({
          lat,
          lon,
          country: 'Hold cursor briefly for country & category...',
          loading: true,
        });

        if (timerRef.current) window.clearTimeout(timerRef.current);
        const currentSeq = ++seqRef.current;

        timerRef.current = window.setTimeout(async () => {
          const [country, obsResult] = await Promise.all([
            resolveCountryName(lat, lon, geocodingLib),
            fetchNasaPowerPoint(lat, lon, false)
              .then((obs) => ({ obs }))
              .catch(() => ({
                error: 'No NASA POWER land climate data here (ocean point).',
              })),
          ]);

          if ('obs' in obsResult && obsResult.obs) {
            cacheRef.current.set(cacheKey, { country, obs: obsResult.obs });
            if (seqRef.current !== currentSeq) return;
            const { sc, category, climateType } = scoreObs(obsResult.obs);
            onUpdateCursor({
              lat,
              lon,
              country,
              loading: false,
              obs: obsResult.obs,
              climateType,
              climateScore: sc,
              category,
            });
          } else {
            const errMsg =
              'error' in obsResult
                ? obsResult.error
                : 'Unavailable at this point.';
            cacheRef.current.set(cacheKey, { country, error: errMsg });
            if (seqRef.current !== currentSeq) return;
            onUpdateCursor({
              lat,
              lon,
              country,
              loading: false,
              error: errMsg,
            });
          }
        }, 320);
      }
    );

    const outListener = map.addListener('mouseout', () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
      seqRef.current++;
      onUpdateCursor(null);
    });

    return () => {
      moveListener.remove();
      outListener.remove();
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [map, geocodingLib, onUpdateCursor, scoreObs]);

  return null;
};

interface ClickedPointState {
  lat: number;
  lon: number;
  country?: string;
  loading: boolean;
  error?: string;
  obs?: NasaPowerObservation;
  climateType?: string;
  climateScore?: number;
  category?: { label: string; color: string };
  nearestName: string;
  nearestKm: number;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function buildClickedPopupHtml(
  point: ClickedPointState,
  targetName: string,
  siteCount: number
): string {
  const countryBlock =
    point.country && point.country !== 'Ocean / Unmapped Region'
      ? `<div style="font-size:12px;color:#475569;margin-top:2px;">Country: <b>${escapeHtml(
          point.country
        )}</b></div>`
      : '';

  let bodyBlock = '';
  if (point.loading) {
    bodyBlock = `<div style="color:#475569;margin-top:6px;">Loading NASA POWER data...</div>`;
  } else if (point.error) {
    bodyBlock = `<div style="color:#be123c;margin-top:6px;">${escapeHtml(
      point.error
    )}</div>`;
  } else {
    bodyBlock = `
      <div style="color:#475569;margin-top:2px;">
        Climate type: <b>${escapeHtml(point.climateType ?? '')}</b>
      </div>
      <hr style="margin:8px 0;border:0;border-top:1px solid #e2e8f0;" />
      <div>
        Category for <b>${escapeHtml(targetName)}</b>:
        <div style="margin-top:2px;">
          <span style="font-size:15px;font-weight:700;color:${
            point.category?.color ?? '#0f172a'
          };">${escapeHtml(point.category?.label ?? '')}</span>
          <span style="color:#475569;"> (climate match ${
            point.climateScore?.toFixed(0) ?? '—'
          }/100)</span>
        </div>
      </div>
      <div style="color:#1e293b;margin-top:8px;">
        Mean ${point.obs?.temp.toFixed(1) ?? '—'} °C · range ${
      point.obs?.rng.toFixed(0) ?? '—'
    } °C<br/>
        Rain ${point.obs?.rain.toFixed(0) ?? '—'} mm/yr · Pressure ${
      point.obs?.press.toFixed(0) ?? '—'
    } kPa
      </div>
      <div style="font-size:11px;color:#64748b;margin-top:6px;line-height:1.35;">
        NASA POWER. Climate only (temperature, range, rainfall, pressure); ranked against the ${siteCount} surveyed sites.
      </div>
    `;
  }

  return `
    <div style="font-family:Arial,sans-serif;font-size:13px;line-height:1.35;color:#0f172a;min-width:225px;max-width:270px;">
      <div style="font-weight:700;color:#0f172a;">
        Latitude ${point.lat.toFixed(3)}°<br/>
        Longitude ${point.lon.toFixed(3)}°
      </div>
      ${countryBlock}
      ${bodyBlock}
      <div style="color:#475569;margin-top:6px;padding-top:5px;border-top:1px solid #e2e8f0;font-size:12px;">
        Nearest surveyed site: ${escapeHtml(
          point.nearestName
        )} (${point.nearestKm.toLocaleString()} km)
      </div>
    </div>
  `;
}

interface LeafletAnalogMapFallbackProps {
  results: SimilarityResult[];
  allEarthSites: EarthAnalogSite[];
  activeTarget: PlanetaryTargetSite;
  selectedSiteId: string;
  mapTypeId: 'hybrid' | 'satellite' | 'terrain';
  flyTrigger: number;
  lo: number;
  hi: number;
  onSelectSite: (siteId: string) => void;
  onUpdateCursor: (info: CursorInspection | null) => void;
}

const LeafletAnalogMapFallback: React.FC<LeafletAnalogMapFallbackProps> = ({
  results,
  allEarthSites,
  activeTarget,
  selectedSiteId,
  mapTypeId,
  flyTrigger,
  lo,
  hi,
  onSelectSite,
  onUpdateCursor,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const baseLayersRef = useRef<L.Layer[]>([]);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const clickedLayerRef = useRef<L.LayerGroup | null>(null);
  const clickedMarkerRef = useRef<L.CircleMarker | null>(null);
  const cacheRef = useRef<Map<string, CachedLookup>>(new Map());
  const hoverTimerRef = useRef<number | null>(null);
  const hoverSeqRef = useRef(0);
  const clickSeqRef = useRef(0);

  const onSelectSiteRef = useRef(onSelectSite);
  onSelectSiteRef.current = onSelectSite;
  const onUpdateCursorRef = useRef(onUpdateCursor);
  onUpdateCursorRef.current = onUpdateCursor;
  const activeTargetRef = useRef(activeTarget);
  activeTargetRef.current = activeTarget;
  const allEarthSitesRef = useRef(allEarthSites);
  allEarthSitesRef.current = allEarthSites;

  const scoreObs = useCallback((obs: NasaPowerObservation) => {
    const target = activeTargetRef.current;
    const sites = allEarthSitesRef.current;
    const sc = computeClimateMatchScore(obs, target, sites);
    const allScores = sites.map((e) =>
      computeClimateMatchScore(e, target, sites)
    );
    const pct =
      allScores.filter((x) => x <= sc).length / Math.max(1, allScores.length);
    const category =
      pct >= 0.67
        ? { label: 'Strong analog', color: '#16a34a' }
        : pct >= 0.34
        ? { label: 'Moderate analog', color: '#d97706' }
        : { label: 'Weak analog', color: '#dc2626' };
    return { sc, category, climateType: classifyClimate(obs) };
  }, []);

  // Initialize Leaflet map once
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [20, 15],
      zoom: 2,
      minZoom: 2,
      worldCopyJump: true,
    });
    mapRef.current = map;
    markersLayerRef.current = L.layerGroup().addTo(map);
    clickedLayerRef.current = L.layerGroup().addTo(map);

    const invalidateTimer = window.setTimeout(() => {
      map.invalidateSize();
    }, 100);

    map.on('mousemove', (e: L.LeafletMouseEvent) => {
      const lat = e.latlng.lat;
      const lon = ((e.latlng.lng + 540) % 360) - 180;
      const cacheKey = `${(Math.round(lat * 4) / 4).toFixed(2)},${(
        Math.round(lon * 4) / 4
      ).toFixed(2)}`;

      const cached = cacheRef.current.get(cacheKey);
      if (cached) {
        if (hoverTimerRef.current) window.clearTimeout(hoverTimerRef.current);
        if (cached.obs) {
          const { sc, category, climateType } = scoreObs(cached.obs);
          onUpdateCursorRef.current({
            lat,
            lon,
            country: cached.country,
            loading: false,
            obs: cached.obs,
            climateType,
            climateScore: sc,
            category,
          });
        } else {
          onUpdateCursorRef.current({
            lat,
            lon,
            country: cached.country,
            loading: false,
            error: cached.error ?? 'Ocean / no land climate data',
          });
        }
        return;
      }

      onUpdateCursorRef.current({
        lat,
        lon,
        country: 'Hold cursor briefly for country & category...',
        loading: true,
      });

      if (hoverTimerRef.current) window.clearTimeout(hoverTimerRef.current);
      const currentSeq = ++hoverSeqRef.current;

      hoverTimerRef.current = window.setTimeout(async () => {
        const [country, obsResult] = await Promise.all([
          resolveCountryName(lat, lon, null),
          fetchNasaPowerPoint(lat, lon, false)
            .then((obs) => ({ obs }))
            .catch(() => ({
              error: 'No NASA POWER land climate data here (ocean point).',
            })),
        ]);

        if ('obs' in obsResult && obsResult.obs) {
          cacheRef.current.set(cacheKey, { country, obs: obsResult.obs });
          if (hoverSeqRef.current !== currentSeq) return;
          const { sc, category, climateType } = scoreObs(obsResult.obs);
          onUpdateCursorRef.current({
            lat,
            lon,
            country,
            loading: false,
            obs: obsResult.obs,
            climateType,
            climateScore: sc,
            category,
          });
        } else {
          const errMsg =
            'error' in obsResult
              ? obsResult.error
              : 'Unavailable at this point.';
          cacheRef.current.set(cacheKey, { country, error: errMsg });
          if (hoverSeqRef.current !== currentSeq) return;
          onUpdateCursorRef.current({
            lat,
            lon,
            country,
            loading: false,
            error: errMsg,
          });
        }
      }, 320);
    });

    map.on('mouseout', () => {
      if (hoverTimerRef.current) window.clearTimeout(hoverTimerRef.current);
      hoverSeqRef.current++;
      onUpdateCursorRef.current(null);
    });

    map.on('click', (e: L.LeafletMouseEvent) => {
      const lat = e.latlng.lat;
      const lon = ((e.latlng.lng + 540) % 360) - 180;
      const seq = ++clickSeqRef.current;
      const sites = allEarthSitesRef.current;
      const target = activeTargetRef.current;

      const nearest = [...sites]
        .map((s) => ({ s, d: haversineKm(lat, lon, s.lat, s.lon) }))
        .sort((a, b) => a.d - b.d)[0];

      const pointState: ClickedPointState = {
        lat,
        lon,
        loading: true,
        nearestName: nearest.s.name,
        nearestKm: Math.round(nearest.d),
      };

      const layerGroup = clickedLayerRef.current;
      if (!layerGroup) return;
      layerGroup.clearLayers();

      const marker = L.circleMarker([lat, lon], {
        radius: 9,
        color: '#ffffff',
        weight: 3,
        fillColor: '#f5a524',
        fillOpacity: 1,
      }).addTo(layerGroup);
      clickedMarkerRef.current = marker;

      marker
        .bindPopup(
          buildClickedPopupHtml(pointState, target.name, sites.length),
          { maxWidth: 300, closeButton: true }
        )
        .openPopup();

      resolveCountryName(lat, lon, null).then((country) => {
        if (clickSeqRef.current !== seq) return;
        pointState.country = country;
        marker.setPopupContent(
          buildClickedPopupHtml(
            pointState,
            activeTargetRef.current.name,
            allEarthSitesRef.current.length
          )
        );
      });

      fetchNasaPowerPoint(lat, lon, false)
        .then((obs) => {
          if (clickSeqRef.current !== seq) return;
          const { sc, category, climateType } = scoreObs(obs);
          pointState.loading = false;
          pointState.obs = obs;
          pointState.climateType = climateType;
          pointState.climateScore = sc;
          pointState.category = category;
          marker.setPopupContent(
            buildClickedPopupHtml(
              pointState,
              activeTargetRef.current.name,
              allEarthSitesRef.current.length
            )
          );
        })
        .catch(() => {
          if (clickSeqRef.current !== seq) return;
          pointState.loading = false;
          pointState.error =
            'Could not load NASA data here (internet or ocean point).';
          marker.setPopupContent(
            buildClickedPopupHtml(
              pointState,
              activeTargetRef.current.name,
              allEarthSitesRef.current.length
            )
          );
        });
    });

    return () => {
      window.clearTimeout(invalidateTimer);
      if (hoverTimerRef.current) window.clearTimeout(hoverTimerRef.current);
      map.remove();
      mapRef.current = null;
      markersLayerRef.current = null;
      clickedLayerRef.current = null;
    };
  }, [scoreObs]);

  // Sync Esri tile layers for Hybrid / Satellite / Terrain
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    baseLayersRef.current.forEach((layer) => map.removeLayer(layer));
    baseLayersRef.current = [];

    if (mapTypeId === 'terrain') {
      const topo = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
        {
          attribution: 'Tiles &copy; Esri',
          maxZoom: 18,
          zIndex: 1,
        }
      ).addTo(map);
      baseLayersRef.current.push(topo);
    } else {
      const imagery = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
          attribution: 'Tiles &copy; Esri',
          maxZoom: 18,
          zIndex: 1,
        }
      ).addTo(map);
      baseLayersRef.current.push(imagery);

      if (mapTypeId === 'hybrid') {
        const labels = L.tileLayer(
          'https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
          {
            maxZoom: 18,
            zIndex: 2,
          }
        ).addTo(map);
        labels.bringToFront();
        baseLayersRef.current.push(labels);
      }
    }
  }, [mapTypeId]);

  // Render surveyed Earth analog pins
  useEffect(() => {
    const layer = markersLayerRef.current;
    if (!layer) return;
    layer.clearLayers();

    results.forEach((r) => {
      const isSelected = r.site.id === selectedSiteId;
      const norm = hi > lo ? (r.combinedScore - lo) / (hi - lo) : 1;
      const color = scoreToColor(norm);

      const marker = L.circleMarker([r.site.lat, r.site.lon], {
        radius: isSelected ? 10 : 8,
        color: isSelected ? '#22d3ee' : '#ffffff',
        weight: isSelected ? 3 : 2,
        fillColor: color,
        fillOpacity: 0.95,
      });

      const popupHtml = `
        <div style="font-family:Arial,sans-serif;font-size:12px;line-height:1.4;color:#0f172a;max-width:230px;">
          <div style="font-weight:700;font-size:13px;color:#0f172a;">${escapeHtml(
            r.site.name
          )}</div>
          <div style="font-weight:600;color:#0e7490;margin-top:2px;">Match ${r.combinedScore.toFixed(
            1
          )}%</div>
          <div style="color:#334155;margin-top:4px;">${escapeHtml(
            r.site.use
          )}</div>
        </div>
      `;

      marker.bindPopup(popupHtml);
      marker.bindTooltip(`${r.site.name} (${r.combinedScore.toFixed(1)}%)`);
      marker.on('click', (ev) => {
        L.DomEvent.stopPropagation(ev);
        clickedLayerRef.current?.clearLayers();
        onSelectSiteRef.current(r.site.id);
        marker.openPopup();
      });

      marker.addTo(layer);
    });
  }, [results, selectedSiteId, lo, hi]);

  // Pan to site when clicked from sidebar
  useEffect(() => {
    const map = mapRef.current;
    if (!map || flyTrigger === 0) return;
    const site = results.find((r) => r.site.id === selectedSiteId)?.site;
    if (!site) return;
    clickedLayerRef.current?.clearLayers();
    map.setView([site.lat, site.lon], 5, { animate: true });
  }, [flyTrigger, results, selectedSiteId]);

  return (
    <div className="relative w-full h-full bg-[#07090E]">
      <div ref={containerRef} className="w-full h-full" />
      <div className="absolute top-3 right-3 z-[400] pointer-events-none bg-[#0B0F19]/90 border border-slate-700/80 rounded px-2.5 py-1 text-[11px] font-mono text-slate-300 shadow">
        Map provider: Leaflet + Esri (Fallback)
      </div>
    </div>
  );
};

interface LeafletMiniMapFallbackProps {
  site: EarthAnalogSite;
}

const LeafletMiniMapFallback: React.FC<LeafletMiniMapFallbackProps> = ({
  site,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.CircleMarker | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [site.lat, site.lon],
      zoom: 8,
      attributionControl: false,
    });

    L.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      { maxZoom: 18 }
    ).addTo(map);

    L.tileLayer(
      'https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
      { maxZoom: 18 }
    ).addTo(map);

    const marker = L.circleMarker([site.lat, site.lon], {
      radius: 8,
      color: '#ffffff',
      weight: 2,
      fillColor: '#06b6d4',
      fillOpacity: 1,
    }).addTo(map);
    marker.bindTooltip(site.name);

    mapRef.current = map;
    markerRef.current = marker;

    const t = window.setTimeout(() => map.invalidateSize(), 100);

    return () => {
      window.clearTimeout(t);
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!mapRef.current || !markerRef.current) return;
    mapRef.current.setView([site.lat, site.lon], 8, { animate: true });
    markerRef.current.setLatLng([site.lat, site.lon]);
    markerRef.current.setTooltipContent(site.name);
  }, [site.id, site.lat, site.lon, site.name]);

  return <div ref={containerRef} className="w-full h-full" />;
};

interface GoogleGlobalMapCanvasProps {
  results: SimilarityResult[];
  allEarthSites: EarthAnalogSite[];
  activeTarget: PlanetaryTargetSite;
  selectedSiteId: string;
  selectedResult?: SimilarityResult;
  mapTypeId: 'hybrid' | 'satellite' | 'terrain';
  flyTrigger: number;
  lo: number;
  hi: number;
  onSelectSite: (siteId: string) => void;
  onUpdateCursor: (info: CursorInspection | null) => void;
}

const GoogleGlobalMapCanvas: React.FC<GoogleGlobalMapCanvasProps> = ({
  results,
  allEarthSites,
  activeTarget,
  selectedSiteId,
  selectedResult,
  mapTypeId,
  flyTrigger,
  lo,
  hi,
  onSelectSite,
  onUpdateCursor,
}) => {
  const apiStatus = useApiLoadingStatus();
  const geocodingLib = useMapsLibrary('geocoding');
  const [hoverId, setHoverId] = useState<string | null>(null);
  const [activeMarker, setActiveMarker] =
    useState<google.maps.marker.AdvancedMarkerElement | null>(null);
  const [siteInfoOpen, setSiteInfoOpen] = useState(false);
  const [clickedPoint, setClickedPoint] = useState<ClickedPointState | null>(
    null
  );
  const clickSeqRef = useRef(0);

  const sortedMarkers = useMemo(() => {
    return [...results]
      .sort((a, b) => b.site.lat - a.site.lat)
      .map((item, idx) => ({ item, baseZ: idx }));
  }, [results]);

  const handleMarkerClick = useCallback(
    (siteId: string, marker: google.maps.marker.AdvancedMarkerElement) => {
      onSelectSite(siteId);
      setClickedPoint(null);
      setActiveMarker(marker);
      setSiteInfoOpen(true);
    },
    [onSelectSite]
  );

  useEffect(() => {
    if (flyTrigger === 0) return;
    setClickedPoint(null);
    setSiteInfoOpen(false);
  }, [flyTrigger]);

  const handleMapClick = useCallback(
    (ev: { detail: { latLng?: { lat: number; lng: number } | null } }) => {
      const latLng = ev.detail.latLng;
      if (!latLng) return;

      const lat = latLng.lat;
      const lon = ((latLng.lng + 540) % 360) - 180;
      const seq = ++clickSeqRef.current;

      const nearest = [...allEarthSites]
        .map((e) => ({ e, d: haversineKm(lat, lon, e.lat, e.lon) }))
        .sort((a, b) => a.d - b.d)[0];

      setSiteInfoOpen(false);
      setClickedPoint({
        lat,
        lon,
        loading: true,
        nearestName: nearest.e.name,
        nearestKm: Math.round(nearest.d),
      });

      resolveCountryName(lat, lon, geocodingLib).then((country) => {
        if (clickSeqRef.current !== seq) return;
        setClickedPoint((prev) => (prev ? { ...prev, country } : prev));
      });

      fetchNasaPowerPoint(lat, lon, false)
        .then((obs) => {
          if (clickSeqRef.current !== seq) return;
          const sc = computeClimateMatchScore(obs, activeTarget, allEarthSites);
          const allScores = allEarthSites.map((e) =>
            computeClimateMatchScore(e, activeTarget, allEarthSites)
          );
          const pct =
            allScores.filter((x) => x <= sc).length /
            Math.max(1, allScores.length);

          const category =
            pct >= 0.67
              ? { label: 'Strong analog', color: '#16a34a' }
              : pct >= 0.34
              ? { label: 'Moderate analog', color: '#d97706' }
              : { label: 'Weak analog', color: '#dc2626' };

          setClickedPoint((prev) =>
            prev
              ? {
                  ...prev,
                  loading: false,
                  obs,
                  climateType: classifyClimate(obs),
                  climateScore: sc,
                  category,
                }
              : prev
          );
        })
        .catch(() => {
          if (clickSeqRef.current !== seq) return;
          setClickedPoint((prev) =>
            prev
              ? {
                  ...prev,
                  loading: false,
                  error:
                    'Could not load NASA data here (internet or ocean point).',
                }
              : prev
          );
        });
    },
    [allEarthSites, activeTarget, geocodingLib]
  );

  if (
    apiStatus === APILoadingStatus.FAILED ||
    apiStatus === APILoadingStatus.AUTH_FAILURE
  ) {
    return (
      <LeafletAnalogMapFallback
        results={results}
        allEarthSites={allEarthSites}
        activeTarget={activeTarget}
        selectedSiteId={selectedResult?.site.id ?? selectedSiteId}
        mapTypeId={mapTypeId}
        flyTrigger={flyTrigger}
        lo={lo}
        hi={hi}
        onSelectSite={onSelectSite}
        onUpdateCursor={onUpdateCursor}
      />
    );
  }

  return (
    <div className="relative w-full h-full">
      <GoogleMap
        mapId="DEMO_MAP_ID"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        defaultCenter={{ lat: 20, lng: 15 }}
        defaultZoom={2}
        gestureHandling="greedy"
        clickableIcons={false}
        disableDefaultUI={false}
        mapTypeControl={false}
        streetViewControl={false}
        onClick={handleMapClick}
        className="w-full h-full"
      >
        {selectedResult && (
          <MapCameraSync
            selectedSite={selectedResult.site}
            mapTypeId={mapTypeId}
            flyTrigger={flyTrigger}
          />
        )}

        <MapCursorTracker
          allEarthSites={allEarthSites}
          activeTarget={activeTarget}
          onUpdateCursor={onUpdateCursor}
        />

        {sortedMarkers.map(({ item, baseZ }) => {
          let zIndex = baseZ;
          if (hoverId === item.site.id) zIndex = Z_INDEX_HOVER;
          if (selectedResult?.site.id === item.site.id)
            zIndex = Z_INDEX_SELECTED;

          const norm = hi > lo ? (item.combinedScore - lo) / (hi - lo) : 1;

          return (
            <AnalogMarkerItem
              key={item.site.id}
              result={item}
              color={scoreToColor(norm)}
              zIndex={zIndex}
              isSelected={selectedResult?.site.id === item.site.id}
              onSelect={handleMarkerClick}
              onHoverChange={setHoverId}
            />
          );
        })}

        {siteInfoOpen && activeMarker && selectedResult && (
          <InfoWindow
            anchor={activeMarker}
            pixelOffset={[0, -4]}
            onCloseClick={() => setSiteInfoOpen(false)}
          >
            <div className="p-1 text-slate-900 max-w-[240px] text-xs space-y-1">
              <div className="font-bold text-sm text-slate-900">
                {selectedResult.site.name}
              </div>
              <div className="font-semibold text-cyan-700">
                Match {selectedResult.combinedScore.toFixed(1)}%
              </div>
              <p className="text-slate-700 leading-snug">
                {selectedResult.site.use}
              </p>
            </div>
          </InfoWindow>
        )}

        {clickedPoint && (
          <AdvancedMarker
            position={{ lat: clickedPoint.lat, lng: clickedPoint.lon }}
            zIndex={Z_INDEX_SELECTED + 10}
          >
            <div
              className="w-5 h-5 rounded-full border-[3px] border-white shadow-lg"
              style={{ backgroundColor: '#f5a524' }}
            />
          </AdvancedMarker>
        )}

        {clickedPoint && (
          <InfoWindow
            position={{ lat: clickedPoint.lat, lng: clickedPoint.lon }}
            pixelOffset={[0, -14]}
            onCloseClick={() => setClickedPoint(null)}
          >
            <div
              className="p-0.5 text-slate-900 min-w-[230px] max-w-[280px] leading-snug"
              style={{ fontFamily: 'Arial, sans-serif', fontSize: '13px' }}
            >
              <div className="font-bold text-slate-900">
                Latitude {clickedPoint.lat.toFixed(3)}°
                <br />
                Longitude {clickedPoint.lon.toFixed(3)}°
              </div>
              {clickedPoint.country &&
                clickedPoint.country !== 'Ocean / Unmapped Region' && (
                  <div className="text-xs text-slate-600 mt-0.5">
                    Country: <b>{clickedPoint.country}</b>
                  </div>
                )}

              {clickedPoint.loading ? (
                <div className="text-slate-600 mt-1.5">
                  Loading NASA POWER data...
                </div>
              ) : clickedPoint.error ? (
                <div className="text-rose-700 mt-1.5">
                  {clickedPoint.error}
                </div>
              ) : (
                <>
                  <div className="text-slate-600 mt-0.5">
                    Climate type: <b>{clickedPoint.climateType}</b>
                  </div>
                  <hr className="my-2 border-t border-slate-200" />
                  <div>
                    Category for <b>{activeTarget.name}</b>:
                    <div className="mt-0.5">
                      <span
                        className="text-base font-bold"
                        style={{ color: clickedPoint.category?.color }}
                      >
                        {clickedPoint.category?.label}
                      </span>{' '}
                      <span className="text-slate-600">
                        (climate match {clickedPoint.climateScore?.toFixed(0)}/100)
                      </span>
                    </div>
                  </div>
                  <div className="text-slate-800 mt-2">
                    Mean {clickedPoint.obs?.temp.toFixed(1)} °C · range{' '}
                    {clickedPoint.obs?.rng.toFixed(0)} °C
                    <br />
                    Rain {clickedPoint.obs?.rain.toFixed(0)} mm/yr · Pressure{' '}
                    {clickedPoint.obs?.press.toFixed(0)} kPa
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1.5 leading-snug">
                    NASA POWER. Climate only (temperature, range, rainfall, pressure); ranked against the {allEarthSites.length} surveyed sites.
                  </div>
                </>
              )}

              <div className="text-slate-600 mt-1.5 pt-1 border-t border-slate-200">
                Nearest surveyed site: {clickedPoint.nearestName} (
                {clickedPoint.nearestKm.toLocaleString()} km)
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
      <div className="absolute top-3 right-3 z-10 pointer-events-none bg-[#0B0F19]/90 border border-slate-700/80 rounded px-2.5 py-1 text-[11px] font-mono text-slate-300 shadow">
        Map provider: Google Maps
      </div>
    </div>
  );
};

interface GlobalAnalogMapProps {
  results: SimilarityResult[];
  allEarthSites: EarthAnalogSite[];
  activeTarget: PlanetaryTargetSite;
  selectedSiteId: string;
  onSelectSite: (siteId: string) => void;
  hasApiKey: boolean;
}

export const GlobalAnalogMap: React.FC<GlobalAnalogMapProps> = ({
  results,
  allEarthSites,
  activeTarget,
  selectedSiteId,
  onSelectSite,
  hasApiKey,
}) => {
  const [mapTypeId, setMapTypeId] = useState<'hybrid' | 'satellite' | 'terrain'>(
    'hybrid'
  );
  const [flyTrigger, setFlyTrigger] = useState(0);
  const [cursorInfo, setCursorInfo] = useState<CursorInspection | null>(null);

  const selectedResult = useMemo(
    () => results.find((r) => r.site.id === selectedSiteId) ?? results[0],
    [results, selectedSiteId]
  );

  const { lo, hi } = useMemo(() => {
    if (results.length === 0) return { lo: 0, hi: 100 };
    const scores = results.map((r) => r.combinedScore);
    return { lo: Math.min(...scores), hi: Math.max(...scores) };
  }, [results]);

  const handleSelectFromSidebar = useCallback(
    (siteId: string) => {
      onSelectSite(siteId);
      setFlyTrigger((n) => n + 1);
    },
    [onSelectSite]
  );

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-61px)] w-full overflow-hidden bg-[#07090E]">
      {/* Left Sidebar */}
      <aside className="w-full lg:w-[370px] max-h-[40vh] lg:max-h-none shrink-0 border-b lg:border-b-0 lg:border-r border-slate-800 bg-[#0B0F19] flex flex-col overflow-hidden">
        <div className="p-4 border-b border-slate-800 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-sm font-semibold text-slate-100">
              Global Analog Survey Sites
            </h2>
            <span className="text-xs font-mono tabular-nums text-slate-400">
              {results.length} sites
            </span>
          </div>

          <div className="flex items-center gap-1 p-1 bg-[#07090E] border border-slate-800 rounded">
            {(['hybrid', 'satellite', 'terrain'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setMapTypeId(mode)}
                className={`flex-1 px-2.5 py-1.5 text-xs font-medium rounded capitalize transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  mapTypeId === mode
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          <p className="text-xs text-slate-400 leading-snug">
            Click anywhere on the map (or hover over any country) to see its coordinates and analog category for the selected target.
          </p>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80">
          {results.map((r) => {
            const active = r.site.id === selectedResult?.site.id;
            return (
              <button
                key={r.site.id}
                type="button"
                onClick={() => handleSelectFromSidebar(r.site.id)}
                className={`w-full text-left px-4 py-3 transition-colors cursor-pointer ${
                  active ? 'bg-cyan-950/30' : 'hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <span className="text-xs font-mono text-slate-400">
                    {r.site.focus} · {r.site.region}
                  </span>
                  <span className="text-xs font-mono tabular-nums font-semibold text-cyan-400">
                    {r.combinedScore.toFixed(1)}%
                  </span>
                </div>
                <div className="text-sm font-medium text-slate-100 truncate">
                  {r.site.name}
                </div>
                <div className="text-xs text-slate-400 font-mono tabular-nums mt-0.5">
                  {r.site.lat.toFixed(3)}°, {r.site.lon.toFixed(3)}° ·{' '}
                  {r.site.elev} m
                </div>
              </button>
            );
          })}
        </div>
      </aside>

      {/* Interactive Map (Google Maps primary, Leaflet + Esri fallback when key missing or failed) */}
      <div className="relative flex-1 min-w-0 min-h-[320px] h-full">
        {hasApiKey ? (
          <GoogleGlobalMapCanvas
            results={results}
            allEarthSites={allEarthSites}
            activeTarget={activeTarget}
            selectedSiteId={selectedSiteId}
            selectedResult={selectedResult}
            mapTypeId={mapTypeId}
            flyTrigger={flyTrigger}
            lo={lo}
            hi={hi}
            onSelectSite={onSelectSite}
            onUpdateCursor={setCursorInfo}
          />
        ) : (
          <LeafletAnalogMapFallback
            results={results}
            allEarthSites={allEarthSites}
            activeTarget={activeTarget}
            selectedSiteId={selectedResult?.site.id ?? selectedSiteId}
            mapTypeId={mapTypeId}
            flyTrigger={flyTrigger}
            lo={lo}
            hi={hi}
            onSelectSite={onSelectSite}
            onUpdateCursor={setCursorInfo}
          />
        )}

        {/* Live Cursor Country, Latitude/Longitude & Category Readout */}
        {cursorInfo && (
          <div className="absolute bottom-4 left-4 z-[400] pointer-events-none bg-[#0B0F19]/95 border border-slate-700/90 rounded px-3.5 py-2.5 text-xs shadow-xl max-w-[330px] space-y-1">
            <div className="flex items-center justify-between gap-4 font-mono tabular-nums text-[11px] text-slate-300">
              <span>Lat {cursorInfo.lat.toFixed(3)}°</span>
              <span>Lon {cursorInfo.lon.toFixed(3)}°</span>
            </div>
            <div className="font-semibold text-slate-100 truncate">
              {cursorInfo.country}
            </div>
            {cursorInfo.loading ? (
              <div className="text-[11px] font-mono text-slate-400">
                Reading climate category...
              </div>
            ) : cursorInfo.error ? (
              <div className="text-[11px] text-slate-400">
                {cursorInfo.error}
              </div>
            ) : (
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span
                    className="font-semibold"
                    style={{ color: cursorInfo.category?.color }}
                  >
                    {cursorInfo.category?.label}
                  </span>
                  <span className="text-[11px] font-mono tabular-nums text-slate-400">
                    ({cursorInfo.climateScore?.toFixed(0)}/100 ·{' '}
                    {cursorInfo.climateType})
                  </span>
                </div>
                {cursorInfo.obs && (
                  <div className="text-[11px] font-mono tabular-nums text-slate-400">
                    {cursorInfo.obs.temp.toFixed(1)} °C ·{' '}
                    {cursorInfo.obs.rain.toFixed(0)} mm/yr ·{' '}
                    {cursorInfo.obs.press.toFixed(0)} kPa
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

interface GoogleMiniMapCanvasProps {
  site: EarthAnalogSite;
  flyTrigger: number;
  onStatusChange: (failed: boolean) => void;
}

const GoogleMiniMapCanvas: React.FC<GoogleMiniMapCanvasProps> = ({
  site,
  flyTrigger,
  onStatusChange,
}) => {
  const apiStatus = useApiLoadingStatus();
  const failed =
    apiStatus === APILoadingStatus.FAILED ||
    apiStatus === APILoadingStatus.AUTH_FAILURE;

  useEffect(() => {
    onStatusChange(failed);
  }, [failed, onStatusChange]);

  if (failed) {
    return <LeafletMiniMapFallback site={site} />;
  }

  return (
    <GoogleMap
      mapId="DEMO_MAP_ID"
      internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
      defaultCenter={{ lat: site.lat, lng: site.lon }}
      defaultZoom={8}
      gestureHandling="cooperative"
      disableDefaultUI={true}
      zoomControl={true}
      className="w-full h-full"
    >
      <MapCameraSync
        selectedSite={site}
        mapTypeId="hybrid"
        flyTrigger={flyTrigger}
      />
      <AdvancedMarker
        position={{ lat: site.lat, lng: site.lon }}
        title={site.name}
      >
        <div
          className="w-5 h-5 rounded-full border-2 border-white shadow-md"
          style={{ backgroundColor: '#06b6d4' }}
        />
      </AdvancedMarker>
    </GoogleMap>
  );
};

interface SiteSatelliteMiniMapProps {
  site: EarthAnalogSite;
  hasApiKey: boolean;
}

export const SiteSatelliteMiniMap: React.FC<SiteSatelliteMiniMapProps> = ({
  site,
  hasApiKey,
}) => {
  const [flyTrigger, setFlyTrigger] = useState(1);
  const [googleFailed, setGoogleFailed] = useState(false);

  useEffect(() => {
    setFlyTrigger((n) => n + 1);
  }, [site.id]);

  const usingLeaflet = !hasApiKey || googleFailed;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs font-mono text-slate-400">
        <span>
          {usingLeaflet
            ? 'Satellite View · Leaflet + Esri (Fallback)'
            : 'Satellite View · Google Maps'}
        </span>
        <span className="tabular-nums">
          {site.lat.toFixed(2)}°, {site.lon.toFixed(2)}°
        </span>
      </div>

      <div className="h-[300px] w-full rounded border border-slate-800 overflow-hidden bg-[#07090E]">
        {hasApiKey ? (
          <GoogleMiniMapCanvas
            site={site}
            flyTrigger={flyTrigger}
            onStatusChange={setGoogleFailed}
          />
        ) : (
          <LeafletMiniMapFallback site={site} />
        )}
      </div>
    </div>
  );
};
