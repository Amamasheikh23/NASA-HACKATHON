import React from 'react';
import { RotateCcw } from 'lucide-react';
import {
  ANALOG_DIMENSIONS,
  AnalogDimensionKey,
  DimensionWeights,
  PLANETARY_TARGETS,
  PlanetaryTargetSite,
  SimilarityResult,
} from '../data/planetaryAnalogs';
import { RadarComparisonChart } from './RadarComparisonChart';
import { SiteSatelliteMiniMap } from './GlobalAnalogMap';
import moonImg from '../assets/images/moon_lunar_orbit_1794672605116.jpg';
import marsImg from '../assets/images/mars_red_planet_1794672605782.jpg';

interface DiscoveryLabViewProps {
  targetId: string;
  onChangeTarget: (targetId: string) => void;
  bodyFilter: 'All' | 'Moon' | 'Mars';
  onChangeBodyFilter: (filter: 'All' | 'Moon' | 'Mars') => void;
  weights: DimensionWeights;
  onChangeWeight: (key: AnalogDimensionKey, val: number) => void;
  onResetWeights: () => void;
  results: SimilarityResult[];
  selectedSiteId: string;
  onSelectSite: (siteId: string) => void;
  onOpenMap: (siteId: string) => void;
  hasApiKey: boolean;
}

export const DiscoveryLabView: React.FC<DiscoveryLabViewProps> = ({
  targetId,
  onChangeTarget,
  bodyFilter,
  onChangeBodyFilter,
  weights,
  onChangeWeight,
  onResetWeights,
  results,
  selectedSiteId,
  onSelectSite,
  onOpenMap,
  hasApiKey,
}) => {
  const activeTarget: PlanetaryTargetSite =
    PLANETARY_TARGETS.find((t) => t.id === targetId) ?? PLANETARY_TARGETS[0];

  const activeResult: SimilarityResult =
    results.find((r) => r.site.id === selectedSiteId) ?? results[0];

  const { site } = activeResult;
  const targetImage = activeTarget.focus === 'Moon' ? moonImg : marsImg;

  const classColor = (cls: SimilarityResult['matchClass']) =>
    cls === 'High Fidelity'
      ? 'text-emerald-400'
      : cls === 'Partial Match'
      ? 'text-amber-400'
      : 'text-rose-400';

  return (
    <div className="flex flex-col lg:flex-row min-h-[calc(100vh-61px)] w-full bg-[#07090E]">
      {/* Left Calibration Column */}
      <aside className="w-full lg:w-[360px] shrink-0 border-b lg:border-b-0 lg:border-r border-slate-800 bg-[#0B0F19] p-5 space-y-5">
        <section className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Target Mission Site
            </h2>
            <span className="text-xs font-mono uppercase text-cyan-400">
              {activeTarget.focus}
            </span>
          </div>

          <select
            value={targetId}
            onChange={(e) => onChangeTarget(e.target.value)}
            aria-label="Target planetary mission site"
            className="w-full bg-[#111827] border border-slate-700 rounded px-3 py-2 text-xs font-medium text-slate-100 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <optgroup label="Moon Targets (5)">
              {PLANETARY_TARGETS.filter((t) => t.focus === 'Moon').map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </optgroup>
            <optgroup label="Mars Targets (2)">
              {PLANETARY_TARGETS.filter((t) => t.focus === 'Mars').map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </optgroup>
          </select>

          <div className="bg-[#07090E] border border-slate-800 rounded overflow-hidden text-xs">
            <div className="aspect-video w-full bg-black overflow-hidden border-b border-slate-800/80 p-1.5 flex items-center justify-center">
              <img
                src={targetImage}
                alt={`${activeTarget.focus} orbital view`}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="p-3 space-y-2">
              <div className="font-semibold text-slate-100">
                {activeTarget.name}
              </div>
              <p className="text-slate-400 leading-relaxed">{activeTarget.use}</p>
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between font-mono tabular-nums text-[11px] text-slate-400">
                <span>Temp: {activeTarget.temp} °C</span>
                <span>Gravity: {activeTarget.gravity} m/s²</span>
              </div>
            </div>
          </div>
        </section>

        <section className="space-y-2">
          <div className="text-xs font-mono uppercase tracking-wider text-slate-400">
            Analog Site Scope
          </div>
          <div className="flex items-center gap-1 p-1 bg-[#07090E] border border-slate-800 rounded">
            {(['All', 'Moon', 'Mars'] as const).map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => onChangeBodyFilter(filter)}
                className={`flex-1 px-2.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                  bodyFilter === filter
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Similarity Weights
            </h2>
            <button
              type="button"
              onClick={onResetWeights}
              className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-cyan-400 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          <div className="space-y-2.5">
            {ANALOG_DIMENSIONS.map((dim) => (
              <div key={dim.key} className="space-y-1">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="text-slate-200 truncate">{dim.label}</div>
                    <div
                      className={`text-[10px] font-mono ${
                        dim.provenance === 'computed'
                          ? 'text-cyan-400/90'
                          : 'text-amber-400/80'
                      }`}
                    >
                      {dim.provenanceLabel}
                    </div>
                  </div>
                  <span className="font-mono tabular-nums text-cyan-400 shrink-0">
                    {weights[dim.key].toFixed(2)}×
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1.5}
                  step={0.05}
                  value={weights[dim.key]}
                  onChange={(e) =>
                    onChangeWeight(dim.key, Number(e.target.value))
                  }
                  className="w-full analog-slider"
                  aria-label={`${dim.label} similarity weight`}
                />
              </div>
            ))}
          </div>
        </section>
      </aside>

      {/* Main Stage: Ranked Table + Concise Dossier */}
      <main className="flex-1 min-w-0 p-6 space-y-5 overflow-y-auto">
        <section className="bg-[#0B0F19] border border-slate-800 rounded overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold text-slate-100">
                Ranked Earth analog candidates
              </h2>
              <p className="text-xs font-mono text-slate-400 mt-0.5">
                {results.length} sites · exploratory heuristic decision-support index (60% weighted Euclidean + 40% cosine; not a measured planetary similarity score)
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase bg-[#080B12] text-[11px]">
                  <th className="py-2.5 px-4">Rank</th>
                  <th className="py-2.5 px-4">Earth Analog Location</th>
                  <th className="py-2.5 px-4">Focus</th>
                  <th className="py-2.5 px-4">Match</th>
                  <th className="py-2.5 px-4">Cos / Euc</th>
                  <th className="py-2.5 px-4">Slope</th>
                  <th className="py-2.5 px-4">Class</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {results.map((r, idx) => {
                  const isSelected = r.site.id === site.id;
                  return (
                    <tr
                      key={r.site.id}
                      onClick={() => onSelectSite(r.site.id)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-cyan-950/30' : 'hover:bg-slate-900/50'
                      }`}
                    >
                      <td className="py-2.5 px-4 font-mono tabular-nums text-slate-400">
                        #{idx + 1}
                      </td>
                      <td className="py-2.5 px-4">
                        <div className="font-semibold text-slate-100">
                          {r.site.name}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {r.site.region}
                        </div>
                      </td>
                      <td className="py-2.5 px-4 font-mono whitespace-nowrap text-cyan-400">
                        {r.site.focus}
                      </td>
                      <td className="py-2.5 px-4 font-mono tabular-nums font-semibold text-cyan-300">
                        {r.combinedScore.toFixed(1)}%
                      </td>
                      <td className="py-2.5 px-4 font-mono tabular-nums text-slate-300">
                        {r.cosineSimilarity.toFixed(0)} /{' '}
                        {r.euclideanSimilarity.toFixed(0)}
                      </td>
                      <td className="py-2.5 px-4 font-mono tabular-nums text-slate-300">
                        {r.site.slope.toFixed(1)}°
                      </td>
                      <td
                        className={`py-2.5 px-4 font-medium whitespace-nowrap ${classColor(
                          r.matchClass
                        )}`}
                      >
                        {r.matchClass}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Concise Selected Dossier */}
        <section className="bg-[#0B0F19] border border-slate-800 rounded p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="text-xs font-mono text-slate-400 mb-0.5">
                {site.region} · {site.lat.toFixed(2)}°, {site.lon.toFixed(2)}° ·{' '}
                {site.elev} m
              </div>
              <h2 className="text-xl font-semibold text-slate-100">
                {site.name}
              </h2>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="px-3.5 py-1.5 bg-[#07090E] border border-slate-800 rounded font-mono tabular-nums">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">
                  Analog Index
                </div>
                <div className="text-lg font-bold text-cyan-400">
                  {activeResult.combinedScore.toFixed(1)}%
                </div>
              </div>

              <button
                type="button"
                onClick={() => onOpenMap(site.id)}
                className="px-3.5 py-2 text-xs font-medium rounded border border-slate-700 text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap cursor-pointer"
              >
                Open Global Map
              </button>

              <span
                className={`text-xs font-semibold ${classColor(
                  activeResult.matchClass
                )}`}
              >
                {activeResult.matchClass}
              </span>
            </div>
          </div>

          {/* 2x2 Telemetry Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3 bg-[#07090E] border border-slate-800 rounded">
              <div className="text-xs text-slate-400">
                Mean temp / annual swing
              </div>
              <div className="mt-1 text-base font-mono font-semibold tabular-nums text-slate-100">
                {site.temp.toFixed(1)} °C{' '}
                <span className="text-xs font-normal text-amber-400">
                  ±{site.rng.toFixed(1)} °C
                </span>
              </div>
            </div>

            <div className="p-3 bg-[#07090E] border border-slate-800 rounded">
              <div className="text-xs text-slate-400">
                Mean slope (est.) / annual precip
              </div>
              <div className="mt-1 text-base font-mono font-semibold tabular-nums text-slate-100">
                {site.slope.toFixed(1)}°{' '}
                <span className="text-xs font-normal text-slate-400">
                  · {site.rain.toFixed(1)} mm/yr
                </span>
              </div>
            </div>

            <div className="p-3 bg-[#07090E] border border-slate-800 rounded">
              <div className="text-xs text-slate-400">
                Surface pressure / solar flux
              </div>
              <div className="mt-1 text-base font-mono font-semibold tabular-nums text-slate-100">
                {site.press.toFixed(1)} kPa{' '}
                <span className="text-xs font-normal text-cyan-400">
                  · {site.solar != null ? `${site.solar.toFixed(1)} kWh/m²/day` : '—'}
                </span>
              </div>
            </div>

            <div className="p-3 bg-[#07090E] border border-slate-800 rounded">
              <div className="text-xs text-slate-400">Data source</div>
              <div className="mt-1 text-xs font-semibold text-slate-100">
                {site.src}
              </div>
              <div className="mt-1 text-[11px] font-mono text-amber-400/90 leading-snug">
                Thermal uses NASA POWER temp &amp; annual range. Terrain uses a slope formula on estimated slope (not NASA elevation rasters). Geology, water/ice, subsurface, dust/wind, biosignatures &amp; mobility are literature-based estimates.
              </div>
            </div>
          </div>

          <div className="space-y-2 text-xs leading-relaxed">
            <p className="text-slate-300">
              <strong className="text-slate-100">Useful for:</strong> {site.use}
            </p>
            <p className="text-slate-300">
              <strong className="text-slate-100">
                Where the analogy breaks down:
              </strong>{' '}
              {site.limits}
            </p>
          </div>

          {/* 2-Column Visual Stage: 8-Axis Radar + Embedded Map */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start pt-2">
            <div className="xl:col-span-5 p-4 bg-[#07090E] border border-slate-800 rounded">
              <RadarComparisonChart
                earthName={site.name}
                targetName={activeTarget.name}
                earthVector={site.vector}
                targetVector={activeTarget.vector}
              />
            </div>

            <div className="xl:col-span-7 p-4 bg-[#07090E] border border-slate-800 rounded">
              <SiteSatelliteMiniMap site={site} hasApiKey={hasApiKey} />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
