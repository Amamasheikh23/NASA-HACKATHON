import React from 'react';
import earthImg from '../assets/images/earth_planet_orbit_1794672604590.jpg';
import moonImg from '../assets/images/moon_lunar_orbit_1794672605116.jpg';
import marsImg from '../assets/images/mars_red_planet_1794672605782.jpg';

interface ScientificBriefViewProps {
  nasaLoadedCount: number;
  totalEarthSites: number;
}

export const ScientificBriefView: React.FC<ScientificBriefViewProps> = ({
  nasaLoadedCount,
  totalEarthSites,
}) => {
  return (
    <div className="max-w-[920px] mx-auto px-6 py-8">
      <div className="bg-[#0B0F19] border border-slate-800 rounded p-6 md:p-8 space-y-6 text-sm leading-relaxed">
        <div className="flex flex-wrap items-baseline justify-between gap-2 pb-4 border-b border-slate-800">
          <div>
            <h1 className="text-2xl font-semibold text-slate-100">
              Scientific Brief
            </h1>
            <p className="text-xs font-mono text-slate-400 mt-1">
              NASA Space Apps Challenge - Earth as a Laboratory
            </p>
          </div>
          <div className="text-xs font-mono text-cyan-400">
            Team NOVA FIVE
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {[
            { name: 'Earth', img: earthImg },
            { name: 'Moon', img: moonImg },
            { name: 'Mars', img: marsImg },
          ].map((body) => (
            <div
              key={body.name}
              className="bg-[#07090E] border border-slate-800 rounded overflow-hidden"
            >
              <div className="aspect-video w-full bg-black overflow-hidden p-1.5 flex items-center justify-center">
                <img
                  src={body.img}
                  alt={body.name}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="px-2.5 py-1.5 text-xs font-mono text-slate-300 text-center">
                {body.name}
              </div>
            </div>
          ))}
        </div>

        <section className="space-y-1.5">
          <h2 className="text-base font-semibold text-cyan-400">Question</h2>
          <p className="text-slate-300">
            Which places on Earth best match candidate Moon-base and Mars exploration sites, and where does each analogy break down?
          </p>
        </section>

        <section className="space-y-1.5">
          <h2 className="text-base font-semibold text-cyan-400">Method</h2>
          <p className="text-slate-300">
            Every site is described by an 8-axis profile: geology, terrain, thermal extremes, water/ice and ISRU, subsurface, dust/wind, biosignatures, and mobility. Each Earth site is compared with the selected Moon or Mars target using a weighted Euclidean similarity (60%) and a weighted cosine similarity (40%), with sliders adjusting mission weights live. Because only the thermal axis uses live NASA climatology and the remaining axes rely on estimated slopes or literature values rather than orbital raster measurements, this combined score is an{' '}
            <strong className="text-slate-100">
              exploratory heuristic decision-support index—never a measured planetary similarity score
            </strong>
            .
          </p>
        </section>

        <section className="space-y-1.5">
          <h2 className="text-base font-semibold text-cyan-400">
            Data &amp; Transparency
          </h2>
          <ul className="list-disc pl-5 space-y-1.5 text-slate-300">
            <li>
              <strong className="text-slate-100">
                Thermal Axis (NASA POWER Data):
              </strong>{' '}
              Calculated using mean temperature and annual temperature range data fetched live from the{' '}
              <strong className="text-slate-100">NASA POWER Climatology API</strong>{' '}
              ({nasaLoadedCount} of {totalEarthSites} Earth sites loaded), alongside rainfall, surface pressure, and solar flux.
            </li>
            <li>
              <strong className="text-slate-100">
                Terrain Axis (Slope Formula on Estimated Slope):
              </strong>{' '}
              Calculated using a normalized slope formula (<span className="font-mono text-slate-200">slope / 20</span>), but the underlying slope values (and site elevations) are manually entered estimates—
              <strong className="text-amber-300">
                not NASA elevation raster measurements
              </strong>{' '}
              (such as NASADEM, ASTER, or LRO LOLA).
            </li>
            <li>
              <strong className="text-slate-100">
                Six Literature-Based Estimate Axes:
              </strong>{' '}
              Geology, water/ice, subsurface, dust/wind, biosignatures, and mobility are hand-set literature-based estimates from published planetary analog studies,{' '}
              <strong className="text-amber-300">
                not computed from NASA orbital rasters
              </strong>{' '}
              (MODIS, NASADEM, ASTER, LOLA, or MRO CRISM).
            </li>
            <li>
              <strong className="text-slate-100">
                5 Moon &amp; 2 Mars Targets:
              </strong>{' '}
              Shackleton Rim, Marius Hills, Mare Tranquillitatis, Aristarchus Plateau, Tycho Crater, Jezero Crater, and Utopia Planitia values are taken from published NASA/LRO/MRO mission descriptions.
            </li>
          </ul>
        </section>

        <section className="space-y-1.5">
          <h2 className="text-base font-semibold text-cyan-400">
            Highlight: Kharan-Chagai, Balochistan
          </h2>
          <p className="text-slate-300">
            An under-studied desert basin used as a hypothesis. Its climate numbers come from NASA POWER data, while its geology and other non-climate scores are hand-set estimates, so it is a lead for further field and orbital investigation rather than a confirmed analog.
          </p>
        </section>

        <section className="space-y-1.5">
          <h2 className="text-base font-semibold text-cyan-400">
            Limits of every Earth analog
          </h2>
          <p className="text-slate-300">
            Earth cannot reproduce reduced gravity (Moon 1.62 m/s², Mars 3.71 m/s²), the lunar vacuum, the thin Martian CO₂ atmosphere, or unshielded space radiation. Temperature range is annual on Earth and day-night on the Moon and Mars, so that comparison is approximate.
          </p>
        </section>

        <section className="space-y-1.5 p-4 bg-[#07090E] border border-slate-800 rounded">
          <h2 className="text-base font-semibold text-amber-400">
            AI Use Disclosure (Team NOVA FIVE)
          </h2>
          <p className="text-slate-300 text-xs leading-relaxed">
            In accordance with NASA Space Apps Challenge transparency guidelines, <strong className="text-slate-100">Team NOVA FIVE</strong> discloses that generative AI tools were used to assist with coding (React/TypeScript/Tailwind), interface development, data visualizations (radar chart and Google Maps/Leaflet overlays), illustrative planetary image generation, and drafting documentation and UI copy. While the team directed the project concept and reviewed the presentation and provenance labels, the underlying NASA POWER climatology values, estimated slopes, literature-based axis scores, and exploratory heuristic calculations have not been independently scientifically verified.
          </p>
        </section>

        <section className="space-y-1.5">
          <h2 className="text-base font-semibold text-cyan-400">Next steps</h2>
          <ul className="list-disc pl-5 space-y-1 text-slate-300">
            <li>
              Replace the manually estimated slope values and the six literature-based axes with automated raster statistics from NASADEM, MODIS, ASTER, LRO LOLA, and MRO CRISM
            </li>
            <li>Search a global grid for unrecognized analogs</li>
            <li>Validate high-priority leads such as Kharan-Chagai with mineralogical spectroscopy</li>
          </ul>
        </section>
      </div>
    </div>
  );
};
